# South Asia — echolocation call records (batch 1 of 5 for Asia)

Afghanistan, Bangladesh, Bhutan, India, Nepal, Pakistan, Sri Lanka, Maldives. **155 species** (per the authoritative 2025/2026 checklist), of which **145 use laryngeal, nasal, or lingual echolocation**.

This batch looks different from every previous one, and for a good reason: a systematic review answering almost exactly this project's question for this exact region was published one month before this conversation (26 November 2025). Rather than reconstruct that synthesis from scratch, this batch is built directly on it.

**Headline number, stated by the source itself, not computed by this pipeline: 86–87 species (60%) of South Asia's 145 echolocating species have at least one published or unpublished echolocation observation, compiled into 299 standardized observations from 35 peer-reviewed papers plus ~6,190 unpublished recordings plus the ChiroVox database.**

Files: `southasia_full_checklist.csv`, `southasia_species_with_data.csv` (all 86–87 species, complete, with their exact literature sources), `southasia_call_records.csv` (quantitative values — partial, see caveat below), `southasia_sources.csv`.

## The one serious limitation, stated plainly

The review paper's own data table (Supplementary Material 3, 299 observations with per-observation FMAXE, high/low frequency, duration, bandwidth, sweep rate, detector, region and recording condition) is longer than this pipeline's fetch could pull back in one call. **181 individual trait records were captured — roughly the first third, covering Vespertilionidae (partial) and Hipposideros (through *H. lankadiva*) — before the fetch truncated.** The rest of the table exists in the open-access source and was not retrieved. This is the single highest-value acquisition target of anything in this entire project: one more paginated fetch of the same PDF would likely complete South Asia to a standard no other continent has reached.

The species-level list of *which* 86–87 species have data, and from which papers, is complete (`southasia_species_with_data.csv`) — only the numeric values themselves are partial.

## The checklist denominator has its own small gap, honestly disclosed

The live checklist webpage (v1.10) was scraped directly and yielded 138 named species against the review paper's stated total of 155, with 19 gaps in the checklist's own numbering. Whether those gaps are additional species dropped by the scrape or subspecies-level rows was not resolved — 155, the paper's own cited figure, is used as the denominator throughout rather than the 138 actually captured by name. The underlying master Excel file could not be parsed (binary, and the host isn't in this pipeline's whitelisted domains).

## Findings — mostly the source's own, and they're excellent

**Eight sonotypes cover the entire regional fauna**, a cleaner structural summary than most sources in this project have offered: Short CF (Hipposideros), Long CF (Rhinolophus), FM (*Harpiocephalus, Hesperoptenus, Kerivoula, Miniopterus, Murina, Myotis, Phoniscus, Submyotodon*), FM-QCF (*Arielulus, Cnephaeus, Eudiscopus, Hypsugo, Mirostrellus, Nyctalus, Pipistrellus, Scotophilus, Tylonycteris*), Long Multiharmonic (*Mops, Otomops, Rhinopoma, Tadarida, Taphozous*), Megadermatid, Plecotine, and Barbastelle (its own category — the alternating bidirectional nose/mouth emission already documented for European *Barbastella* in this project's batch 2 recurs here in its South Asian congener).

**A cryptic-species signal hiding in a "nomen nudum."** *Rhinolophus rouxii* calling at ~94 kHz in Tamil Nadu and the southern Western Ghats was formally named *R. indorouxii* by Chattopadhyay et al. 2012 — but the name was never validly published and is now synonymized back under *R. rouxii*. The acoustic and genetic signal that prompted the naming attempt is still there in the data (91–94 kHz southern populations vs. 74–82 kHz elsewhere), a live example of a species boundary sitting exactly on the edge of what call data alone can resolve.

**A measured, named example of misidentification risk from geographic variation** — the exact failure mode this project has repeatedly inferred, now caught explicitly by the paper's authors: *Pipistrellus tenuis* calls reported at 38 kHz FMAXE from one Karnataka site are flagged by the review's own authors as more likely *P. ceylonicus*, whose expected range (35–45 kHz) overlaps that value, versus *P. tenuis*'s expected ~50 kHz.

**Detector and recording-condition metadata is tracked at a level no other batch in this project has matched.** Table 4 in the source cross-tabulates 299 observations against 15 named detector models (Anabat SD1/Walkabout, five Pettersson models, Wildlife Acoustics SM3/SM4/EchoMeter, Ultrasound Advice) and five recording conditions. This is exactly the schema this project has been building toward from batch 1 onward, already done, at scale, for a whole subcontinent.

**Detectability bias is quantified with a named metric.** The paper's "Echolocation Knowledge Ratio" (species with data / species richness per grid cell) shows over 90% of South Asia's land area falls into "no species recorded" or "low survey priority" — including nearly all of Afghanistan and Bangladesh, all of Bhutan, and large parts of Pakistan, Nepal and northern/central India. "Good knowledge" areas (EKR ≥ 0.25) cover only about 3% of the region, concentrated in the Western Ghats, Uttarakhand, and a few Indian states with major universities nearby — the paper explicitly notes the data-density clusters near Dehradun, Madurai and Hyderabad track academic institutions, not bat diversity.

**One species-level gap is total and worth flagging on its own.** *Triaenops persicus*, South Asia's only representative of Rhinonycteridae, has no echolocation data reported anywhere in the systematic review.

## Verification status

Zero verified rows, consistent with every batch in this project.

## Asia tranche status

South Asia (this batch) is 1 of 5 proposed Asia sub-batches. Remaining: Mainland Southeast Asia (Myanmar, Thailand, Laos, Cambodia, Vietnam), Maritime/Insular Southeast Asia (Malaysia, Indonesia, Philippines, Brunei, Singapore, Timor-Leste — likely the largest single sub-batch, Indonesia alone may exceed 200 species), East Asia (China, Taiwan, Japan, Korea, Mongolia), and Central Asia & the Middle East.
