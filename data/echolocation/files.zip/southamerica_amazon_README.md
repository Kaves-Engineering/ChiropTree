# South America — batch 1: Brazil & Amazon Basin (corrected)

This replaces the batch-1 README. It documents the checks and fixes requested after an audit against the actual named Brazil checklist (Garbino et al. 2024, 186 species) turned up real errors, not just gaps.

**Final coverage: 99/186 = 53.2%** (up from an initial uncritical estimate of "~45%", corrected once to 48.4%, now 53.2% after four rounds of fixes and targeted searches below). Every one of the 186 species is marked `covered` or `MISSING` by name in `southamerica_amazon_brazil_coverage_audit.csv`.

| Family | Covered/Total |
|---|---|
| Emballonuridae | 14/17 |
| Phyllostomidae | 39/96 |
| Mormoopidae | 3/4 |
| Noctilionidae | 2/2 |
| Furipteridae | 1/1 |
| Thyropteridae | 2/5 |
| Natalidae | 1/1 (qualitative only, see below) |
| Molossidae | 19/33 |
| Vespertilionidae | 18/27 |

## Errors found and fixed

**Taxonomy, not just gaps.** Two Mormoopidae rows were filed under retired names. *Pteronotus parnellii* is now restricted to the Antilles (Pavan & Marroig 2016); mainland South American populations recorded under that name are *P. rubiginosus*. Fixed by renaming and annotating. *P. davyi*'s only prior Brazilian records were reidentified as *P. gymnonotus* — its data is retained (valid for the species elsewhere in South America) but excluded from Brazil's count.

**The primary source itself carried outdated taxonomy.** Yoh et al. 2020 measured two species under names since retired for Brazil: *Tonatia saurophila* (restricted to a Jamaican fossil by Basantes et al. 2020 — the living Amazonian animals are something else, most plausibly *T. bidens* or *T. maresi*, unresolvable without a voucher check) and *Carollia castanea* (a doubtful record for Brazil, confirmed range being Central America/NW South America). Both flagged in the records and excluded from the Brazil count until resolved.

**An outright omission.** Batch 1 had already fetched Arias-Aguilar et al.'s Furipteridae/Natalidae/Thyropteridae table in full but never mined it — Emballonuridae, Molossidae, Mormoopidae, Noctilionidae and Vespertilionidae got extracted, this table didn't. Fixed: *Furipterus horrens* (3 harmonics, SA-Tr), *Thyroptera discifera* and *T. tricolor* are now in `southamerica_furipteridae_natalidae_thyropteridae_records.csv`. A missed *Eptesicus (Neoeptesicus) furinalis* SA-Tr row from the same Vespertilionidae table was also caught and added.

**A genuine equipment artifact, now documented rather than silently inherited.** Early *Furipterus horrens* recordings suffered aliasing — the equipment's sampling rate was less than double the species' very high call frequency, so early published values likely understate its true frequencies (Falcão et al. 2015, cited in Arias-Aguilar 2018). Flagged on every *F. horrens* record.

## New data found by targeted per-species search

Six species moved from no-data to real values, three via a primary source I'd previously only cited second-hand:

- ***Nyctinomops macrotis*** and ***Promops centralis*** — full means, SDs and sample sizes, fetched directly from Jung, Molinari & Kalko 2014 (PLoS ONE, open access), which I had flagged as "not yet ingested" in an earlier batch and finally fetched. *N. macrotis* is the lowest-frequency molossid the source measured, plausibly linked to its specialization on large moth prey. *P. centralis*'s distinctive alternating call (~26 kHz up-modulated / ~30–36 kHz down-modulated) — already known qualitatively from three other sources — now has primary numbers, and the source itself is why the species' known Brazilian range was extended by acoustic survey alone.
- ***Diaemus youngii*** — echolocation FME ≈ 63 kHz, distinct from a much lower-frequency social contact call (~21 kHz), sourced through Carter et al.'s vampire-bat work. Citation not fully pinned down; flagged `medium` confidence.
- ***Natalus macrourus*** — Arias-Aguilar et al. state explicitly they present "the first spectrogram" and quantitative parameters for this species, but the numbers sit only in a figure image, not extractable table text. Marked `value_exists_unretrieved`, the strongest form of "this is a real measurement I haven't gotten to."
- ***Diphylla ecaudata*** and ***Lasiurus villosissimus*** — same treatment: real, citable spectrograms/descriptions exist (a labelled echolocation pulse for *Diphylla*; a Chilean acoustic description for *L. villosissimus*) but no number was in the retrievable text.

## Genuine, source-confirmed absences — not inferred, not guessed

Four Vespertilionidae species — ***Histiotus alienus, Lasiurus ebenus, Myotis izecksohni, Myotis simus*** — are marked `unknown_no_data` on the strength of Arias-Aguilar et al.'s own explicit statement that they searched and found nothing for these species by name (grouped in their text with two others that don't occur in Brazil). This is the correct basis for that evidence class: a systematic review's stated negative, not an inference from a family-level generalization. Four more (*Myotis pampa*, *M. lavali*, *Neoeptesicus taddeii*, *N. diminutus*) got the same label after an individual dated search of my own turned up nothing — all are recently described or very rare Brazilian (near-)endemics.

## What's still missing, honestly

87 species, concentrated in three places:

1. **Phyllostomidae nectarivores** (Glossophaginae/Lonchophyllinae: *Anoura*, *Glossophaga*, *Lonchophylla*, *Choeroniscus*, *Lichonycteris*, *Scleronycteris*, *Hsunycteris*, *Lionycteris*, *Dryadonycteris*, *Xeronycteris* — roughly 15 species). Searched specifically; nothing dedicated turned up beyond the three genera already in the Yoh dataset.
2. **Small Stenodermatinae** (*Platyrrhinus* — 9 of 10 Brazilian species, *Sturnira*, *Vampyressa*, *Vampyrodes*, *Chiroderma*, *Uroderma magnirostrum*, *Pygoderma*, *Sphaeronycteris*). One real qualitative finding surfaced: a 2021 study found these genera are consistently nasal (not oral) emitters — logged as a structural fact, not a frequency.
3. **Molossidae/Vespertilionidae rarities**: mostly species with very restricted ranges, very recent descriptions, or genuine field difficulty (*Eumops chimaera*, *E. trumbulli*, *Cynomops mastivus*/*milleri*, several *Molossus*).

Thyropteridae's 3 remaining gaps (*T. devivoi*, *T. lavali*, *T. wynneae*) are stated as literally "inexistent" knowledge by Arias-Aguilar's own text — as solid a `unknown_no_data` as this project has produced anywhere.

## Flagged for the next revision, not yet done

Jung et al. 2014's primary data should be used to upgrade several existing `measured_compiled` (Arias-Aguilar-sourced) rows to `measured_primary`, and to resolve some of the Central America/batch-4 Molossidae composite entries to individual species. Not done in this pass — noted so it isn't silently lost.

## Verification status

Zero verified rows, as in every batch to date.
