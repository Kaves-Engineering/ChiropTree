# North America — echolocation call records, batch 3

Scope: the United States and Canada. 45 species, 252 records, 9 sources. **40 of 45 species have measured parameter values** — the best coverage of any batch so far, and by a wide margin.

Files: `northamerica_call_records.csv`, `northamerica_species.csv`, `northamerica_sources.csv`. Same schema as the revised Europe batch.

## Why this batch went so much better

Two open PDFs from the Cal Poly Humboldt Bat Lab do almost all the work. Szewczak's *Echolocation Call Characteristics of Western North American Bats* (~200,000 species-known, tracked-bat calls) and its eastern counterpart (~42,000 calls) give, for 38 species: characteristic frequency, high frequency, low frequency, frequency of maximum energy, call duration, four slope measures, and a prose description of diagnostic call shape. Each with a mean, a ±1 SD interval, and the total observed range.

Nothing in Europe came close. EuroBaTrait is bigger but I could not download it; these two are plain URLs that fetched on the first attempt.

## Coverage

| | species |
|---|---|
| Measured values from the SonoBat tables | 38 |
| Measured, other sources | 2 |
| `value_exists_unretrieved` | 1 (*Mormoops megalophylla*) |
| `unknown_no_data`, searched and dated | 6 |
| **Total** | **45** |

## The one big caveat on the SonoBat means

The bold means and SDs are computed over **the subset of each species' repertoire with the most species-discriminating characteristics** — the calls the classifier can confidently assign. They are not the mean of what the species emits. They are biased toward classifiable calls by construction.

The small-print total ranges are the honest description of the repertoire, and they are much wider. *Myotis californicus* has a characteristic frequency mean of 49.5 kHz with an SD interval of 47–52, but a full range of 43–57. For high frequency the same species runs 52–135 kHz against a mean of 91.

Both are in the table: `value` and `dispersion_value` hold the discriminating-subset figures, `value_min`/`value_max` hold the full range. Rendering only the mean would misrepresent every species here. The author says so directly — that the parameters "do not typically foster confident species identification any more than would overlapping physical characteristics such as fur color or body weight."

## Findings

**A near-perfect convergence pair.** *Parastrellus hesperus* (west, ƒc 46.1 kHz) and *Perimyotis subflavus* (east, ƒc 42.6 kHz) have essentially identical structural descriptions in the source — strongly inflected almost-vertical FM dropping to low slope below 47 kHz, hockey-stick shaped, some calls with "squiggles." Different genera, allopatric, same call design. Good material for the tree page.

**Two species the source says may be inseparable.** *Lasiurus borealis* and *L. seminolus* have ƒc means identical to one decimal place (40.4 kHz both), and the eastern table states outright they are possibly acoustically indistinguishable. Their `notes` fields record this.

**Frequency alternation again.** New World molossids in *Eumops*, *Molossus* and *Nyctinomops* alternate between two or three frequencies within a sequence. The SonoBat single ƒc for *E. perotis*, *E. floridanus*, *N. femorosaccus* and *N. macrotis* collapses that pattern into one number. This is the same data-model problem as *Nyctalus* and *Barbastella* in Europe, now on a second continent — strong argument for making alternation a first-class field rather than a note.

**A species that is nearly unrecordable.** The Sonozotz project explicitly lists *Eumops underwoodi* among species it could not record: roosts unknown or inaccessible, and it forages hundreds to thousands of metres above ground. That is a structural gap, categorically different from "nobody has studied it."

**The lowest-frequency bat in the dataset.** *Euderma maculatum*, ƒc 9.3 kHz — audible to humans, and lower than anything in Europe including *Tadarida teniotis* at 11.4 kHz.

**Rafinesque's big-eared bat is a fake data point.** *Corynorhinus rafinesquii* is in the eastern table, but its "total range" columns collapse to single values (high frequency 40–40, low frequency 22–22, ƒmaxE 33–33, duration 2.6–2.6). That is what n≈1 looks like. It is flagged in the record notes; the mean and SD printed alongside cannot be trusted.

## Data-quality flags raised against the sources

Six records carry a suspected source or PDF-extraction error, where a printed value is inconsistent with its own range: *Idionycteris phyllotis* ƒc, *Nyctinomops macrotis* high frequency and duration, *Antrozous pallidus* high-frequency mean, *Myotis septentrionalis* high-frequency range, *Myotis velifer* duration range. Each is flagged in `notes`. These need checking against the published PDF.

One structural oddity: *Eumops floridanus* (east) and *Eumops perotis* (west) have near-identical values across every parameter. Possible genuine similarity, possible copying between tables. Worth verifying.

And the eastern table's own text says its figures derive from "the western library," which is either a typo or an undocumented dependency between the two tables.

## Scope decisions you should overrule if you disagree

**Mexico is excluded.** NABat defines its 47 species as those *shared by* Canada, the United States and Mexico, but Mexico has around 140 bat species. Including it would triple the list and pull in the Neotropical phyllostomid radiation. Mexico belongs with the Central America batch biogeographically, and Sonozotz (69 Mexican species, open access) is the right instrument for it.

**The species list is reconstructed, not authoritative.** I could not retrieve NABat's actual 47-species list; I assembled 45 from the US list plus Canadian species. Reconcile against NABat before publishing. Likely omissions are the Florida Keys *Artibeus jamaicensis* and vagrant records.

**Taxonomy is unreconciled with your MDD backbone.** *Lasiurus blossevillii* appears as *Lasiurus frantzii* in the western table; *Aeorestes*, *Dasypterus* and *Parastrellus* placements vary. No GBIF or MDD identifiers are attached yet — that join still needs doing, and it matters more here than in Europe because the North American vespertilionid genera have been actively resplit.

## Verification status

Zero verified rows, as with every previous batch. Every `verified_by` is empty.
