# Europe — echolocation call records, batch 2 (revised)

47 species. 176 call records + 4 ancillary metrics, across 39 sources. This revision fixes the validation failures in the first version and adds per-species searching for every species that previously had none.

Files: `europe_call_records.csv`, `europe_ancillary_metrics.csv`, `europe_species.csv`, `europe_sources.csv`.

## Coverage, before and after

| | first version | revised |
|---|---|---|
| Species with at least one measured value | 19 | **32** |
| Species with no acoustic data at all | 14 | **2** |
| `unknown_no_data` records | 40 | **11** |
| Sources | 24 | 39 |

The two species still with nothing are *Plecotus sardus* and *Plecotus tenerifae*, and both now carry a `last_searched` date, so the claim of ignorance is dated and falsifiable rather than assumed.

## What was wrong and what changed

**The false gap claims.** The first version marked 14 species `unknown_no_data` without ever searching for them individually. That inverted my own rule from batch 1 — absent means not ingested, `unknown_no_data` is a scientific claim. Twelve of those fourteen turned out to have published data. *Tadarida teniotis* has a full parameter set from southern Switzerland (mean amplitude-maximum frequency 11.4 kHz, end frequency 10.7 kHz, duration 8–27 ms, interpulse interval 740 ms). *Nyctalus azoreum* has peak 27–33 kHz. *Pipistrellus maderensis* has 45–47 kHz. *Plecotus macrobullaris* has a dedicated *Acta Chiropterologica* paper. Every remaining `unknown_no_data` row now carries `last_searched`.

**New evidence class: `value_exists_unretrieved`.** Distinct from both absent and unknown. It means a source measured the value and I could not read it — the number sits in a figure or behind a paywall. Two records: *Rhinolophus blasii* resting frequency (measured in Bulgaria, n=56, value in a figure) and *Plecotus austriacus* Madeira parameters (measured, 791 recordings, paywalled). These are acquisition targets, not knowledge gaps, and must never render as "no data".

**Two more classes added:** `not_separable` (a species-level value cannot exist because the species is not acoustically distinguishable — *M. blythii*) and `inferred_genus`.

**Sample sizes and dispersion now have columns.** `n_individuals`, `n_calls`, `dispersion_type`, `dispersion_value`. The rhinolophid SDs, the 12 *M. emarginatus* individuals, the 52 Iberian *Eptesicus*, the 791 Madeira recordings and the Bulgarian sample sizes are queryable instead of buried in prose.

**One-sided bounds are explicit.** `value_type` takes point / range / lower_bound / upper_bound / categorical. "End frequency >29 kHz" is now `lower_bound`, not a range with a missing top.

**Resting frequency separated from CF.** New trait `resting_frequency_kHz` for stationary handheld rhinolophids. Doppler shift compensation means the frequency emitted in flight sits systematically below resting frequency, so the two were never the same measurement.

**Non-call metrics moved out.** Hearing range, detection range, source level and classifier accuracy now live in `europe_ancillary_metrics.csv`.

**Citation status is now a field.** `source_status` marks each source resolved / unresolved_citation / session_url / paywalled_book. Eight source keys are flagged unresolved, including the ones where I had supplied an author list or title I had not actually read.

## New findings from the deeper pass

**Detectability bias is now quantified.** A Maltese survey recorded *R. hipposideros*, *M. punicus* and *P. austriacus* in 2% of survey time against 92% for the *Pipistrellus* group — all three being low-intensity callers. *P. macrobullaris* pulses attenuate so fast that most detectors cannot record it even at 5 m. Any acoustic-derived range map on the site needs this flag.

**Context-dependence is the rule, not the exception.** *P. macrobullaris* call duration runs 0.8 ms near clutter to 7.3 ms over open meadow, and the longer calls shift down to about 42 kHz start and 15 kHz end. A single peak frequency for that species discards the paper's actual finding.

**The cryptic-species problem is worse than batch 2 stated.** *Miniopterus schreibersii* has two genetically diverged lineages in Asia Minor with slightly different call parameters that are not diagnostic for individuals, so a single value pools lineages. *E. isabellinus* vs *E. serotinus* was tested properly on molecularly identified colonies: peak frequency is genuinely higher in *isabellinus*, but they overlap between 23.4 and 28.8 kHz and classification reached only about 78.8%.

**A captive study that must not be ingested.** The *M. myotis* / *M. blythii* work is flagged `measured_primary` with an explicit warning: the authors state their recorded fMAXE values are considerably higher than free-flying values. It is in the sources table specifically so nobody ingests it later by mistake.

## Highest-value acquisitions remaining

1. **EuroBaTrait 1.0** (figshare doi:10.6084/m9.figshare.21777161.v2, CC-BY) — 14 acoustic traits, 46 of 47 species, 1,346,508 calls. figshare blocks automated download. This one file takes coverage to 98%.
2. **Teixeira & Jesus 2009**, *Acta Chiropterologica* 11(1) — the only numeric source for *P. maderensis* and Madeiran *P. austriacus*.
3. **Russ (ed.) 2021, *Bat Calls of Britain and Europe*** — chapters 8.15 and 8.16 are the only dedicated accounts for *M. crypticus* and *M. escalerai*.
4. **Obrist et al. 2004** and **Russo & Jones 2002** — still unresolved from batch 1, still underpinning 31 threshold records and 12 unverified numbers.

## Verification status

Still zero verified rows. Every `verified_by` is empty, and rule 1 from batch 1 applies: nothing with an `evidence_class` starting `measured_` renders until a human fills that field.

Europe is now structurally sound enough to build on.
