# ChiropTree echolocation layer — provenance schema

Two tables, joined to your Mammal Diversity Database v2.5 backbone by `sci_name_mdd` (or better, `mdd_id`).

- `family_call_defaults.csv` — one row per family. Every row is a **synthesis of the literature across the family**, not a measurement of any species.
- `species_call_records.csv` — tidy long format, one row per (species × trait × source). One species can have several rows for the same trait from different studies or regions. This is deliberate: disagreement between sources is information.

## Evidence classes

| Class | Meaning | Render as |
|---|---|---|
| `measured_primary` | Species-level parameters from a study that recorded identified individuals, with method and sample size reported | Solid value, cite the study |
| `measured_compiled` | From a trait database that itself compiled primary literature (EuroBaTrait, Castro et al. 2024). One step removed — the compiler's judgement sits between you and the recording | Solid value, cite the compilation *and* say it is a compilation |
| `modelled_phylogenetic` | Estimated from a model, e.g. body-mass allometry or PhyloPars imputation on a bat supertree. Not an observation | Visually distinct (dashed outline / grey). Never in the same column style as a measurement |
| `inferred_family` | No measurement for this species; the value is the family (or genus) default propagated down | Visually distinct, and label the source as the family, not a paper |
| `not_applicable` | Species does not laryngeally echolocate (most Pteropodidae) | Explicit "does not echolocate", not a blank |
| `unknown_no_data` | Searched, nothing published | Explicit "no published description" |

The distinction that matters most for your stated goal is `unknown_no_data` vs. an absent row. An absent row means *not yet ingested*; `unknown_no_data` means *nobody has measured this*. Only the second is a scientific claim, and only that one should be displayed as a gap. Consider a `last_searched` date on gap rows so the claim stays falsifiable.

## Rules worth enforcing in the build

1. Do not render any row where `evidence_class` starts with `measured_` and `verified_by` is empty. This is what keeps transcription errors and the example rows below out of the published page.
2. Never merge family defaults into the species table as if measured. Keep them in separate columns or separate rows so that "we know this" and "we assume this" can never be confused downstream.
3. Store frequency as `value_min`/`value_max` where the source reports a range, and use `value` only for a central estimate the source actually gives. Do not compute a midpoint of a range and call it a mean.
4. Record `call_phase` (search / approach / terminal) and `recording_context` (in_hand / hand_released / light_tagged / free_flying). Parameters from hand-released bats are systematically different from free-flying search-phase calls, and a lot of tropical data is hand-released. A table that pools them silently is misleading.
5. Two known traps in the family defaults, both flagged in the notes column: Mormoopidae mixes LDC and HDC lineages (only the *Pteronotus parnellii* complex is HDC), and the Vespertilionidae frequency range is so wide it carries essentially no information for an individual species. Genus-level inference is more defensible than family-level for Vespertilionidae, Phyllostomidae and Molossidae.

## Trait vocabulary

`call_type` (CF-FM / FM / FM-QCF / QCF / click / none), `duty_cycle` (high / low), `emission_route` (nasal / oral), `peak_frequency_kHz`, `cf_frequency_kHz`, `start_frequency_kHz`, `end_frequency_kHz`, `bandwidth_kHz`, `call_duration_ms`, `interpulse_interval_ms`, `dominant_harmonic`.

For CF-FM species use `cf_frequency_kHz`, not `peak_frequency_kHz` — they are close but not the same parameter, and rhinolophid CF frequency is the parameter with real taxonomic signal.

## Ingest plan, by evidence class it produces

| Source | Coverage | Yields | Access |
|---|---|---|---|
| Castro et al. 2024, BMC Ecol Evol, doi:10.1186/s12862-024-02231-4, supplementary file | 314 species, global | `measured_compiled`: peak frequency, bandwidth, call duration | Open |
| EuroBaTrait 1.0, doi:10.1038/s41597-023-02157-4 (figshare 21777161) | 47 European species, 118 traits incl. acoustic | `measured_compiled` | Open, CC |
| ChiroVox (chirovox.org) | 192 species, 46 genera, 11 families; >150 species not in any other online source | Recordings + metadata, so `measured_primary` if you measure them yourself; otherwise presence/absence of a reference recording | CC-BY, scrapeable, no API |
| Xeno-canto bats, via the GBIF occurrence API (`Chiroptera` + `mediaType=Sound`) | Growing, Europe/N America biased | Recordings, linkable, stable identifiers | Open API |
| Sonozotz, Zamora-Gutierrez et al. 2020 | 69 species, Mexico (50% of the national fauna) | `measured_primary` | Open |
| SonoBat acoustic tables (sonobat.com) | N American species, means ± SD and full ranges | `measured_compiled` | Free PDFs, cite rather than bulk-copy |
| Family defaults in this repo | All families, hence all species | `inferred_family` | — |

EchoBank (Collen 2012; 53,488 calls, 297 species) is the largest compilation but the sound files are not available online, so it is a citation, not an ingest target.

Note that the container I built this in cannot reach chirovox.org, figshare or GBIF, so nothing here was downloaded — the two example measured rows in `species_call_records.csv` are format demonstrations with values written from memory, flagged in their `notes`, and with `verified_by` deliberately empty so rule 1 excludes them.

## Honest coverage estimate

Roughly 300–400 species have published call parameters of some kind, against ~1,470 recognised species. So the species-level layer will be about 20–25% populated even after ingesting everything above, and the gaps are structured, not random: Neotropical phyllostomids, African and Malagasy taxa, and the small poorly-known families (Furipteridae, Thyropteridae, Myzopodidae, Cistugidae) are close to empty. Showing that pattern on a range map is arguably the most useful thing this page could do.
