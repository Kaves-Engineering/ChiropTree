# South America — batch 2: Ecuador

Second of four South American sub-batches (after Brazil/Amazon; Colombia and Peru remain, plus the Southern Cone and Guianas+Venezuela). Ecuador specifically, because it has the only other dedicated national call-library paper in the region besides Mexico's Sonozotz.

**Coverage: 32/171 = 18.7%** — the lowest of any batch so far, and for a specific, structural reason explained below, not from a thin search.

| Family | Covered/Total |
|---|---|
| Emballonuridae | 5/12 |
| Phyllostomidae | 13/109 |
| Mormoopidae | 1/2 |
| Noctilionidae | 2/2 |
| Furipteridae | 0/2 |
| Thyropteridae | 1/3 |
| Molossidae | 5/21 |
| Vespertilionidae | 5/20 |

Files: `ecuador_call_records.csv`, `ecuador_coverage_audit.csv` (all 171 species, named), `ecuador_sources.csv`.

## The species list itself took most of this batch's effort, and here is why that matters

Getting an actual named Ecuador checklist (rather than just a species count) required working around a ResearchGate block, a bot-detection block on the official mamiferosdelecuador.com host, and a JavaScript single-page-application (bioweb.bio) that returns only navigation HTML to a standard fetch — no species data at all. I eventually found a directly fetchable mirror of Tirira's **2018.1** checklist (171 species, full binomials, family-by-family). That is one to three versions behind current: later editions report 178 (2022.1), 181 (2023.2), and 182 (2024.2) species. **The true denominator is 7–11 species higher than what's audited here** — mostly recent splits and descriptions in *Platyrrhinus*, *Myotis*, *Cynomops*, and *Molossus*. I could not fetch those newer lists to identify exactly which species were added, so the missing-species file is accurate against 2018.1 but incomplete against the true 2026 state of Ecuadorian bat taxonomy.

I also came very close to using the wrong list entirely: a "Bat List" PDF that looked like an Ecuador checklist turned out to be one user's **global life list** from mammalwatching.com — every bat species on Earth with personal "seen" ticks, not an Ecuador fauna list. Caught before use; worth naming because it's exactly the kind of source that looks right at a glance and would have quietly corrupted the whole batch.

## Why coverage is so low: the country's own reference library is locked behind JavaScript

Ecuador has real infrastructure for this — **MammaliaWeb-Ecuador**, run by the PUCE Zoology Museum, has an entire "Ecolocación" section with per-species acoustic reference data. Rivera-Parra & Burneo (2013) describe the project and confirm reliable-identification recordings exist for 28 species (Table 1, reproduced in full in `ecuador_call_records.csv`). But the site itself is a JavaScript SPA: every fetch attempt returned only the navigation shell, no data. **The numbers exist and are citable; they are simply not extractable by this pipeline.** All 28 species are logged as `value_exists_unretrieved`, which is the correct call — this is squarely an acquisition problem, not a knowledge gap, and it is the single highest-value target for your local rerun, since a browser with JavaScript rendering (which you'll have, and I don't) should retrieve it directly from `bioweb.bio/faunaweb/mammaliaweb/Ecolocacion`.

## What is genuinely measured, not just "exists somewhere"

Two categories of real numbers, both reused from the Brazil/Amazon batch because the same species occur in Ecuador:

- **Arias-Aguilar et al. 2018's SA-Tr (South America tropical) rows** — region-general Neotropical measurements, not Ecuador-specific recordings.
- **Jung, Molinari & Kalko 2014's primary Molossidae dataset** — which explicitly included Ecuadorian and Peruvian localities among its ten-year, multi-country sample, so *Promops centralis* and *Nyctinomops macrotis* here carry real means and SDs, not just a proxy flag.

Every one of these is marked as a **regional proxy**, not a local value — a real distinction, since (as the Brazil batch showed for *Myotis riparius* and *Lasiurus blossevillii*) Neotropical species can show several kHz of geographic variation in peak frequency across their range.

## The phyllostomid gap is now the dominant pattern across three countries

13/109 Ecuadorian phyllostomids covered — worse even than Brazil's 39/96 (batch 1) after correction. Ecuador's phyllostomid radiation is exceptionally large (multiple *Platyrrhinus*, *Sturnira*, and *Artibeus*/*Dermanura* species-groups largely endemic to the country's Chocó and Andean-slope forests), and none of the region-general Neotropical sources (Arias-Aguilar, Jung 2014) cover Phyllostomidae at all — Arias-Aguilar explicitly excluded the family, and Jung 2014 is Molossidae-only. The Costa Rica (Leiser-Miller & Santana 2021) and Amazon (Yoh et al. 2020) phyllostomid datasets from earlier batches don't overlap with Ecuador's endemic-heavy fauna enough to help. **A dedicated Ecuadorian or Chocó-region phyllostomid acoustic study, if one exists, was not located in this pass.**

## Verification status

Zero verified rows, consistent with every batch to date.

## Next

Colombia (217 species, the single largest national bat fauna after Indonesia) and Peru (~152–185, depending on source year) remain for the Andean/Pacific tranche. Given how much of this batch went to acquiring a usable checklist, expect the same to be true there — Colombia in particular has an active national standards effort (Martinez-Medina et al. 2021, cited in the Argentina paper) but, as of the last check, still no unified call-reference library, per that same source.
