# Central America — corrections to batch 4

Two corrections were requested. The first is done and it overturns the batch's headline claim. The second is partly done.

## Correction 1: the "phyllostomid wall" was wrong

Batch 4 claimed that for roughly half the region's fauna, missing peak frequency is "a permanent structural property, not a to-do item." That is false, and the evidence was already in documents I had read.

**Leiser-Miller & Santana 2021** (*Ecology and Evolution*, open access) is a field-collected echolocation dataset of **35 phyllostomid species, 21 genera, 153 individuals — recorded entirely in Costa Rica**, at Palo Verde and La Selva. It reports call duration, peak frequency, maximum and minimum frequency, bandwidth and harmonic count for every species, spanning all phyllostomid dietary guilds.

Their result is the opposite of what I asserted: call parameters correctly assigned **61.7%** of species to their taxonomic dietary guild and **77.1%** to their functional guild. The authors state directly that phyllostomids "have more diverse echolocation calls than previously reported" and that previous work deeming their calls uniform was "largely qualitative."

**The "whispering" premise is also wrong.** *Macrophyllum macrophyllum* emits at 111 dB SPL in open space, 105 semi-cluttered, 100 in a flight room (Brinkløv et al. 2010) — against the ~70 dB long assumed for the family. *Trachops cirrhosus* reaches ~100 dB flying, with a beam half-amplitude angle of 12–18° and a directionality index of ~17 dB, among the most directional bat sonar beams measured anywhere. Intensity is a habitat variable, not a species constant, and the family was mischaracterised.

What survives from batch 4 is narrower and still true: phyllostomids are **under-represented in passive acoustic surveys** because low-intensity, highly directional calls in dense forest are hard to record at a distance. That is a detection problem, not an absence of data.

**`centralamerica_phyllostomid_records.csv`** — 253 records, 37 species. The 35 Costa Rican species are `value_exists_unretrieved`: the numeric values are in Appendix S1, which I did not fetch. Three caveats from the authors are recorded per species: these are **release calls from hand-held bats**, not free-flying search calls; **six species rest on n=1**; and the 375 kHz sampling rate may **underestimate frequencies** for species calling above 140 kHz (*Glossophaga soricina*, *Micronycteris microtis*).

One genuine conflict is preserved rather than resolved: *Trachops cirrhosus* at <70 dB SPL (Barclay et al. 1981) versus ~100 dB (Surlykke et al.). Different behaviours, different methods, both rows retained.

## Correction 2: the 11 false gap rows, audited

All 11 are corrected in `centralamerica_call_records.csv`. Seven became `value_exists_unretrieved` — *Chrotopterus auritus*, *Lampronycteris brachyotis*, *Lophostoma brasiliense*, *Micronycteris microtis*, *Phyllostomus discolor*, *Trachops cirrhosus*, *Vampyrum spectrum* — all measured by Leiser-Miller & Santana in Costa Rica. Four remain `unknown_no_data` (*Lonchorhina aurita*, *Macrotus waterhousii*, *Mimon cozumelae*, *Macrophyllum macrophyllum* for peak frequency specifically), now dated and with the basis of the claim stated honestly.

Every one of the 11 now records *why* the original row was wrong: it rested on a family-level statement rather than a species-level search.

`unknown_no_data` in this region fell from 11 records to 4.

## Correction 3: species list — not done

Still outstanding, and it remains the weakest part of the batch. I did not fetch the Costa Rica/Nicaragua key (123 species) or the Honduras revision (113 species), so there is still no enumerated denominator for the region. The "~20% coverage" figure from batch 4 should be treated as unsupported until that list exists — and it is now certainly wrong in the low direction, since 35 phyllostomid species just moved from "no data" to "measured, values pending."

Species now represented across both Central American files: **78**, against a regional estimate of ~146.

## What this episode says about the method

This is the second time I have marked species as having no published calls while looking at citations to their published calls. In batch 2 it was 14 European species; here it was 11 phyllostomids, and the Sonozotz paper I quoted cites Geipel et al. 2013 on *Micronycteris microtis* and Brinkløv et al. 2010 on *Macrophyllum macrophyllum* in the same paragraph I drew the family-level claim from.

The pattern is specific: when a source makes a confident family-level generalisation, I have twice treated it as evidence about every species in that family. It is not. A statement that a family is hard to identify acoustically says nothing about whether individual species have been measured.

Practical implication for your rerun: **no `unknown_no_data` row should ever be written from a family-level or review-level statement.** It requires a species-name search that returned nothing. Worth enforcing as a schema rule rather than a habit.
