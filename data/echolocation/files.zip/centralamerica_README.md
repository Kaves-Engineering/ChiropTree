# Central America — echolocation call records, batch 4

Scope: Belize, Guatemala, El Salvador, Honduras, Nicaragua, Costa Rica, Panama. Roughly **146 species**. Mexico (139 species) is handled as a separate adjacent file, see below.

125 records, 41 species, 8 sources. This is the batch where the method starts to break down, and that is the finding.

Files: `centralamerica_call_records.csv`, `mexico_sonozotz_species.csv`, `centralamerica_sources.csv`.

## Coverage — and the honest number

| | count |
|---|---|
| Species with at least one Central American measured value | 30 |
| Species with structure only (harmonic, call type) | 11 |
| Regional species total (approx.) | **~146** |

So roughly **20% coverage**, against 89% in North America and 68% in Europe. And that understates the problem, because the 20% is almost entirely non-phyllostomid.

## Why: the phyllostomid wall

Central America's bat fauna is dominated by Phyllostomidae — around 80 of the ~146 species. Every serious acoustic source excludes them:

- Arias-Aguilar et al. 2018 left the entire family out of a 93-species review, and their key covers only two phyllostomids in 62 taxa.
- Barataud et al. 2013 reached the same conclusion for French Guiana: the family is acoustically too homogeneous.
- Sonozotz recorded 11 phyllostomid species but states plainly that similarity within the family makes it "almost impossible to detect particular signatures to identify species acoustically."

This is not a sampling gap that more fieldwork closes. Phyllostomid calls are low-intensity, short, multiharmonic FM sweeps used alongside olfaction and vision, and they are similar across genera because the sensory task is similar. For roughly half the region's fauna, `unknown_no_data` on peak frequency is a permanent structural property, not a to-do item.

The documented exception is *Lonchorhina aurita*, which emits unusually intense aerial-insectivore-like calls (Gessinger et al. 2019) and is one of only two phyllostomids in the Arias-Aguilar key.

There is a real consequence for ChiropTree: any acoustic-derived layer will show Central America as nearly empty while showing temperate faunas as well covered. That is a property of the method, not of the bats, and it needs saying on the page.

## What did come through

The Arias-Aguilar tables tag every record by region, so **CA-Tr rows are recordings actually made in Central America**, not just species that occur there. That gave 75 primary measurements across Emballonuridae, Molossidae, Mormoopidae, Noctilionidae and Vespertilionidae.

**Frequency alternation, third continent.** *Cormura*, *Diclidurus* and *Saccopteryx* alternate between two or three frequency bands, and a pulse may be dropped when foraging near the roost. So do *Molossus*, *Cynomops*, *Promops* and *Nyctinomops*. Combined with *Nyctalus*/*Barbastella* in Europe and *Eumops*/*Nyctinomops* in North America, this settles it: **alternation needs to be a first-class field in the schema, not a note.** Roughly a quarter of the species in this batch cannot be represented by one peak frequency. The records store bands as `call_type_variant` (low/middle/high, type I/II).

**Dominant harmonic separates families cleanly.** Emballonuridae and Mormoopidae put peak energy in the **second** harmonic; Molossidae and Neotropical Vespertilionidae on the **fundamental**. That is a genuinely diagnostic, well-attested, family-level trait — much more useful for a tree page than any single frequency.

**The New World's only high-duty-cycle bat.** *Pteronotus parnellii* uses duty cycles above 25%, CF sections over 20 ms, and Doppler shift compensation — convergent with Old World Rhinolophidae. It is also a cryptic species complex with sonotypes at 53, 55, 59, 60 and 62 kHz living in sympatry, so a single "*P. parnellii*" value pools species. Both facts are recorded.

**A species found by sound, not by net.** *Promops centralis* is rarely mist-netted but acoustically distinctive; acoustic survey extended its known Brazilian range by more than 3,000,000 km². The counterpoint to the phyllostomid story.

## Mexico

`mexico_sonozotz_species.csv` holds the Sonozotz species list verbatim: **69 species with per-species sample sizes**, 1,664 individuals, 1,960 call sequences, standardized protocol across eight regions.

Two things to know. First, the **parameter values are not in the paper** — they are in the Dryad deposit (doi:10.5061/dryad.95x69p8g6) and the CONABIO Selia app. Every row is `value_exists_unretrieved`, which is an acquisition target, not a gap. Second, **11 of the 69 species rest on a single recorded individual**, flagged per row.

Recording method is documented per species and matters: 63% hand release, 30% zip-lining. Molossids were released from above 5 m specifically to avoid the atypical FM calls bats produce near the ground. Those are not interchangeable with free-flying search calls.

## Extraction confidence

New column, `extraction_confidence`. The Arias-Aguilar tables are dense and many rows populate only some columns, so for ten records I could not confidently assign a number to SF / EF / FME. Those are marked `medium` with the ambiguity described in `notes` — for example *Rhynchonycteris naso*, where one CA-Tr row gives FME 98.2 kHz and another appears to give ~40/47 kHz. Do not publish `medium` rows without checking the PDF.

Pulse intervals reported as alternating pairs ("170/280 ms") are left unparsed rather than forced into one field.

## Highest-value acquisitions

1. **Sonozotz Dryad deposit** — turns 69 Mexican species from list to data.
2. **Jung, Molinari & Kalko 2014** (PLoS ONE, open) — 18 New World molossids. Open access, simply not yet fetched.
3. **Jung, Kalko & von Helversen 2007** — the primary source behind most emballonurid rows here; paywalled.
4. **Barataud et al. 2013**, French Guiana — 8 families, many shared species.

## Verification status

Zero verified rows across all four batches. Every `verified_by` is empty.
