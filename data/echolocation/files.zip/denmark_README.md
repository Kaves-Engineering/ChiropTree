# Danish bats — echolocation call records, batch 1

17 species (Møller, Baagøe & Degn 2013, Naturstyrelsen). 78 records across 9 sources. Machine-readable in `denmark_call_records.csv`; sources in `denmark_sources.csv`.

## Two new evidence classes this batch

The schema needed two additions, and the reason is the main methodological finding here.

**`identification_threshold`** — 31 of 78 records. Most of the per-species numbers circulating for European bats are *classification decision boundaries* from acoustic-identification keys, not measured distributions. "*Pipistrellus pipistrellus*: peak 43–50.9 kHz" is a rule for assigning an unknown call, tuned so the classes do not overlap. It is not a statement about what the species emits, and the same source assigns 51–52 kHz to a two-species group rather than to either species. Publishing these as "the frequency range of *P. pipistrellus*" would be wrong in a way that is easy to miss, because the numbers look like measurements.

**`field_key_only`** — 8 records. Heterodyne tuning bands (Barataud, the Danish DN list). Useful for fieldwork, not comparable to peak frequency at all.

That leaves 16 `measured_primary` and 18 `measured_compiled` records. So roughly 40% of what I retrieved is a real measurement.

## Summary by species

| Species | Danish | Call type | Peak / diagnostic freq (kHz) | Best evidence | Key sources |
|---|---|---|---|---|---|
| *Myotis daubentonii* | Vandflagermus | FM, steep broadband 90→35 | 49 (1–4 ms calls), 37 (8–14 ms) — medians | measured_primary | S2, S3 |
| *M. dasycneme* | Damflagermus | FM **with QCF mid-section** | 41 (1–4 ms), 35 (>14 ms) — medians | measured_primary | S2 |
| *M. brandtii* | Brandts | FM 95→26, 4–7 ms | — | measured_compiled | S5 |
| *M. mystacinus* | Skægflagermus | FM | **no data** | unknown_no_data | — |
| *M. nattereri* | Frynseflagermus | FM, very wide band | 53; end <21 kHz diagnostic | measured_compiled | S4, S1 |
| *M. bechsteinii* | Bechsteins | FM 35–108 | 61 | measured_compiled | S4 |
| *M. myotis* | Stor museøre | FM, knee ~30 | end 20–23 | identification_threshold | S1, S6 |
| *Eptesicus serotinus* | Sydflagermus | FM-QCF, no alternation | 31 (range 25–55) | measured_compiled | S4, S1 |
| *E. nilssonii* | Nordflagermus | QCF, long calls | 28–31 | identification_threshold | S1, S6 |
| *Vespertilio murinus* | Skimmelflagermus | QCF, explosive onset | **no species-level data** | unknown_no_data | S6, S1 |
| *Nyctalus noctula* | Brunflagermus | QCF, regular alternation | ≤21; ~18 in DK | identification_threshold | S1, S9 |
| *N. leisleri* | Leislers | QCF, softer alternation | 22–26 | identification_threshold | S1 |
| *Pipistrellus pipistrellus* | Pipistrelflagermus | QCF / FM-QCF | 43–50.9 | identification_threshold | S1, S6 |
| *P. pygmaeus* | Dværgflagermus | QCF / FM-QCF | 52.1–63 | identification_threshold | S1 |
| *P. nathusii* | Troldflagermus | QCF / FM-QCF | 34–41.9 | identification_threshold | S1, S6 |
| *Barbastella barbastellus* | Bredøret | **two alternating types** | A 33–35, B 39–43 | measured_primary | S8, S1 |
| *Plecotus auritus* | Langøret | FM, two overlapping harmonics | **no peak value**; 20–80 range | measured_compiled | S5 |

## Findings worth putting on the page

**Peak frequency is duration-dependent in the trawling *Myotis*.** Van de Sijpe reports medians stratified by call length precisely because a single number is misleading: *M. daubentonii* sits at 49 kHz for short calls and 37 kHz for long ones. Any schema that stores one peak-frequency value per species destroys this. The `call_phase` and duration-stratification columns matter.

**Three species have no usable species-level value.** *M. mystacinus* (not separable from *M. brandtii*), *V. murinus* (assignable only to a four-species "Nyctaloid" group), and *P. auritus* (calls too quiet — detection range about 5 m). These are the honest `unknown_no_data` rows, and they are a real result, not a gap in my searching.

**Two species cannot be represented by a single call type at all.** *B. barbastellus* alternates two signal types emitted in different directions through mouth and nose, about 70° apart, both at unusually low source level (81 and 82 dB). *N. noctula* alternates between frequency bands. Storing one `call_type` and one `peak_frequency` for either is a data-model error, not just a precision loss.

**Detectability bias propagates into range maps.** *P. auritus* and the gleaning *Myotis* are quiet; passive acoustic monitoring systematically under-records them. If ChiropTree ever overlays acoustic occurrence data on the tree, that bias needs its own flag.

## Verification status

Every row has `verified_by` and `verified_date` empty. Nothing here has been checked against a primary paper by a human.

Two sources need attention before publication:

- **S1** (31 records) is a Frontiers supplementary DOCX, article 995133. I could not resolve it to a citation. The criteria in it are attributed to Parsons & Jones 2000, Russo & Jones 2002, Pfalzer & Kusch 2003, Obrist et al. 2004, Skiba 2009 and Barataud 2020 — all traceable, but the wrapper is not.
- **S4** (Wikipedia's standard triplet, sourced to Parsons & Jones 2000 and Obrist et al. 2004) supplies the frequency-range / peak / duration values for four species. Obrist et al. 2004 is paywalled in *Mammalia* and I could not retrieve it. These twelve numbers need checking against the original tables.

## What would improve this batch

Three paywalled papers carry most of the real measurements for this fauna: Obrist, Boesch & Flückiger 2004 (*Mammalia* 68:307–322, 26 Swiss species), Russo & Jones 2002 (*J. Zool.* 258:91–103, Italy), and Ahlén & Baagøe 1999 (*Acta Chiropterologica*, Nordic — Baagøe is also the Danish authority). Barataud 2020 *Acoustic Ecology of European Bats* is the standard book. If you have institutional access to any of these, sending me the call-parameter tables would convert most of the 31 `identification_threshold` rows into real measurements with sample sizes.
