# South America — batch 3: Colombia

Third of four South American sub-batches. Colombia is the world's most bat-diverse country (222 species per the current 2025 national checklist), which makes it the largest single national fauna in this entire project — larger than Brazil's 186.

**This batch does not have a full named species audit, and that needs to be said plainly up front.** Unlike Brazil and Ecuador, where a complete binomial checklist was eventually fetched as readable text, Colombia's authoritative list (Sociedad Colombiana de Mastozoologia / SiB Colombia, GBIF dataset doi:10.15472/kl1whs) is distributed only as a Darwin Core Archive ZIP file and a supplementary Excel spreadsheet — both binary formats this pipeline cannot open. The checklist paper's own body text (Ramirez-Chaves et al. 2021, fetched in full) gives the authoritative *count* — 217 species as of 2021, 222 as of the 2025 GBIF resource — and tables of species added/removed in recent revisions, but not the full species-by-species list.

**What this means concretely:** `colombia_call_records.csv` contains real, measured data for **8 species**, and I cannot tell you what fraction of 222 that represents in the audited, name-by-name way the Brazil and Ecuador files do. Treat this batch as "8 confirmed real datapoints, denominator known, roster unavailable to this pipeline" rather than a percentage.

## The real find: primary Colombian fieldwork, fully extracted

Arevalo-Cortes et al. 2024 (Mammal Research, open access, fetched in full) describes 81 free-flying call sequences recorded December 2017–May 2020 across an 8–2668 m elevational gradient in Nariño Department, southwest Colombia. Eight species, three families:

- **Vespertilionidae**: *Myotis albescens*, *M. keaysi*, *M. riparius*, *Lasiurus blossevillii*
- **Molossidae**: *Molossus molossus*, *Tadarida brasiliensis*, *Promops centralis*
- **Emballonuridae**: *Saccopteryx bilineata*

All eight have real means and SDs for start frequency, end frequency, duration and pulse interval, backed by voucher specimens and a 93.25%-accurate discriminant function analysis. *Myotis riparius* and *Lasiurus blossevillii* are first records for the department entirely.

## Findings

**Two more species join the "value depends entirely on where and how you measure" list.** *M. albescens* end frequency here is 38.05 ± 2.56 kHz; elsewhere in the literature (Surlykke & Kalko 2008, Estrada-Villegas 2012) it's reported at 43–46 kHz — a real discrepancy the authors attribute to geographic variation, not error. *M. riparius* end frequency here is 46.93 kHz; a permanent-greenhouse study (Fenton et al. 1999) reported a maximum frequency of 121.9 kHz — a gap the paper's own authors attribute to the recording method (a captive greenhouse versus free flight), not the species. Recording context keeps turning out to matter as much as species identity.

**A documented failure to replicate known behaviour, and the authors' explanation for it.** *Saccopteryx bilineata* is well-established elsewhere as alternating between two call frequencies (~45 and ~48 kHz, Ratcliffe et al. 2011). None of the 10 sequences here showed that alternation. The authors' own explanation: the earlier study recorded bats near a roost perch, where alternation signals foraging behaviour; this study recorded bats foraging over open water, where a single frequency may suffice. A genuine ecological explanation for a null result, not a contradiction.

**Colombia's absence of a national call library is externally documented, not just something this search failed to find.** Martinez-Medina et al. 2021 states directly, as its own opening premise: unlike Mexico (Sonozotz), Ecuador (Rivera-Parra & Burneo), and Brazil (Arias-Aguilar; López-Baucells), Colombia — the world's second most bat-diverse country — has no unified reference library for acoustic identification. That paper exists specifically to propose the standards for building one. So the structural gap in this batch is a real, citable, dated fact about the state of Colombian bat bioacoustics, not a limitation specific to this project.

## Cross-referenced but not newly measured

Several species already in the South America batch-1 (Brazil/Amazon) and Ecuador files also occur in Colombia and share the same measured or region-general values: *Molossus molossus*, *M. rufus*, *Promops centralis*, *Tadarida brasiliensis*, and the trawling/riparian *Myotis* group. Not re-listed here to avoid duplication — see those files.

## Not yet retrieved, flagged for the next pass

- The raw audio from this study is deposited at Xeno-Canto (xeno-canto.org/set/8577) and a regional library (SONAR, Universidad de Nariño). Both are real, open, citable archives not yet mined.
- Buitrago Castaño et al. 2025 reports the first Colombian characterisation of *Lasiurus ega* (Santander, n=6, minimum frequency 30.92 ± 2.85 kHz) — found via abstract only; full text not fetched this pass.
- The Colombian phyllostomid checklist (Solari et al., ~132 species with 118 confirmed) was identified in an earlier search but not re-fetched for acoustic content this batch.
- The GBIF/SiB Darwin Core Archive itself, if downloaded and unzipped locally (trivial on your machine, not possible in this container's tool set), would immediately supply the full named 222-species roster this batch is missing.

## Verification status

Zero verified rows, consistent with every batch to date.

## Next

Peru is the fourth and final Andean/Pacific sub-batch. Given the pattern in this tranche — real acoustic data is often easier to obtain than a clean official checklist — expect to prioritize dedicated Peruvian call studies (Ugarte-Núñez 2020, a 20-species southwest Peru key, was already identified in an earlier search) over another checklist-acquisition fight.
