# Australia & New Zealand — echolocation call records

A genuinely distinct fauna: no Phyllostomidae, no Old World Rhinolophidae/Hipposideridae dominance pattern from Europe/Africa, and — uniquely among all batches so far — a documented case of independent convergent evolution with the Neotropical radiation (*Mystacina*, see below).

**Australia: 27/81 = 33.3%** (species-level, taxonomy-resolved). **New Zealand: 2 of 2 extant species covered**, the third (*Mystacina robusta*) genuinely unrecordable — presumed extinct.

Files: `australia_nsw_call_records.csv`, `australia_coverage_audit.csv` (all 81 species named), `newzealand_call_records.csv`, `australia_nz_sources.csv`.

## The source is exceptional — and the coverage number badly understates it

Pennay, Law & Reinhold (2004), *Bat Calls of New South Wales*, fetched in full, is **the richest single document in this entire project.** For each of 27 species or forms it gives: characteristic frequency range, sample size, call shape, per-region breakdowns across six biogeographic zones of NSW, and — unlike almost every other source used so far — explicit, named confusion species with the specific acoustic feature that does or doesn't separate them.

The 33.3% coverage figure is a geography artifact, not a quality one: this guide covers **New South Wales only**, and Australia's echolocating fauna is heavily concentrated in the tropical north. Every species in Hipposideridae (0/7), Megadermatidae (0/1), and most of Emballonuridae (1/8) is a northern-Australia specialist entirely outside this source's scope. Pteropodidae (0/11) is a structural zero, not a gap: Australian flying foxes, blossom bats and tube-nosed bats do not laryngeally echolocate (the family's occasional lingual-click echolocators, like *Rousettus*, aren't found in Australia). Strip those three non-applicable/out-of-region categories out and the coverage of the *relevant, in-region* fauna is much higher — Vespertilionidae alone is 21/38.

## Findings

**A documented, named example of convergent evolution with a different continent's radiation.** *Mystacina tuberculata*'s echolocation calls are brief, multiharmonic, high-repetition-rate clicks — and the primary literature (Jones et al. 2003, *J. Exp. Biol.*) explicitly compares this design to Neotropical Phyllostomidae. This is a striking, independently-arrived-at parallel: two unrelated lineages on opposite sides of the world, both combining short multiharmonic calls with a generalist, partly non-aerial foraging ecology. *Mystacina* is also the only bat known to produce echolocation calls while walking quadrupedally on the ground foraging — a genuinely unique behaviour worth a page of its own.

**A source that quantifies its own identification uncertainty, which almost none of the other 100+ sources in this project have done.** For *Vespadelus baverstocki*, the authors state outright that only 2 of their 23 reference pulses have museum-specimen confirmation; the other 21 "may be *V. vulturnus* or a mix of both species." Most sources present a clean number; this one shows its work on exactly how shaky that number is.

**A concrete, real-time example of the harmonic-switching problem** already inferred abstractly in earlier batches: *Saccolaimus flaviventris* normally calls at 18–20 kHz but is documented shifting energy to a ~30 kHz harmonic when foraging low over or under a canopy — and the zero-crossing Anabat system can only display whichever harmonic dominates at that instant, so a short recording can misidentify the species as something calling natively at 30 kHz.

**Two of the sharpest geographic discontinuities in call frequency found anywhere in this project.** *Vespadelus regulus* jumps by ~10 kHz over roughly 30 km around Albury. *Vespadelus darlingtoni* shows a clean, monotonic frequency cline across its entire NSW range. Both are far more precisely resolved, spatially, than the "geographic variation exists" findings from South America or Europe — a benefit of a single research group working one contiguous, well-sampled region rather than compiling scattered studies.

**A species whose call has simply never been recorded despite being caught multiple times.** *Mormopterus* species 6 (an undescribed form at time of publication) was captured at three NSW locations, and the guide states plainly: "the call has not yet been recorded." A clean, source-stated absence — structurally identical to *Mystacina robusta* in New Zealand and *Eumops underwoodi* in Mexico (Central America batch).

## Taxonomy — six species/forms excluded from the strict count, and why

Australian bat taxonomy has been heavily revised since 2004. Four 2004 names map cleanly to current ones and were counted (*Kerivoula papuensis*→*Phoniscus papuensis*, *Mormopterus norfolkensis*→*Micronomus norfolkensis*, *Miniopterus schreibersii oceanensis*→*Miniopterus orianae*, *Tadarida australis*→*Austronomus australis*). Six could not be mapped with confidence and are **excluded from the coverage percentage** rather than guessed:

- Four undescribed 2004 "Mormopterus species 2/3/4/6" forms (Adams et al. 1988), since formally described into the current *Ozimops* genus but not resolvable 1:1 without dedicated taxonomic literature this pass didn't fetch.
- *Nyctophilus timoriensis*, since split into *N. major* and *N. sherrini* (with *timoriensis* itself often now restricted to South/Western Australian populations) — the 2004 NSW data cannot be cleanly assigned to one current species.
- The undescribed "*Scotorepens* species (Parnaby 1992)," which the source states is **acoustically indistinguishable from *S. greyii*** on standard parameters — a source-documented identification failure, not a gap.

## Verification status

Zero verified rows, consistent with every batch to date.

## Next

This batch covered only NSW. A genuinely complete Australian audit would need the tropical-north equivalent: Milne (2002) for the Northern Territory, and Bullen & McKenzie's Western Australian *Nyctophilus* work (both cited within the NSW guide itself) would fill most of the Hipposideridae/Megadermatidae/Emballonuridae gap. New Zealand's own primary source (Parsons 1997) should be fetched directly for the per-subspecies/per-population quantitative table — currently only anchor FME values were retrieved, not the full dataset.
