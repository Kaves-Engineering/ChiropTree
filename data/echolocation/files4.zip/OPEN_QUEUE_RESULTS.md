# Open-queue results — the last of what could be fetched from here

Ran the remaining open sources. **Three fetched and ingested**, and one of them forces a correction to three European `unknown_no_data` claims.

New files: `europe_bto_discriminants.csv` (13 records, 12 species), `openqueue_call_records.csv` (9 records).

## 1. BTO European Bat Sound Identification Guide — a correction, not just data

Fetched in full. It contains **no numeric tables** — it works by mining known-species recordings, compiling calls *matched for duration*, and comparing confusion pairs side by side. So its content is duration-conditioned qualitative discriminants, encoded here as a distinct evidence class rather than forced into a frequency field.

**The correction: three species this project recorded as `unknown_no_data` demonstrably have reference recordings.**

| Species | Prior status | Reality |
|---|---|---|
| *Myotis punicus* | unknown_no_data | Full duration-matched comparison vs *M. myotis*, Sardinian material from Mauro Mucedda |
| *Myotis davidii* | unknown_no_data | Full comparison vs *M. mystacinus*, 1.3–10.8 ms |
| *Plecotus kolombatovici* | unknown_no_data | Full comparison vs *P. austriacus*, 1.1–12.8 ms |

All three now sit in the BTO Acoustic Pipeline. They're logged as `value_exists_unretrieved` — an acquisition target, not a knowledge gap. That's the **fourth** time in this project that an `unknown_no_data` claim has proven wrong on closer inspection, which is a strong argument for treating that class as provisional by default.

**It also materially qualifies the `not_separable` flag on *Myotis blythii*.** This dataset marked *M. blythii* as not separable from *M. myotis*, following Russ (2021). The BTO guide agrees separation isn't straightforward, but demonstrates it *is* tractable: for a given duration *M. myotis* is lower in frequency, and the difference is greatest for **long calls (>7.7 ms) in open-space flight, where there is little overlap**. Based on targeted fieldwork in Piedmont, Italy. So the correct flag is "hard, and duration-dependent," not "impossible."

Real discriminants captured for four other gap pairs: *M. mystacinus*/*brandtii* (mystacinus favours calls <1.7 ms, brandtii >5.0 ms up to 6.5 ms; mystacinus lower end frequency for a given duration), *P. kuhlii*/*nathusii* (kuhlii lower, with a downward hook and >5 kHz bandwidth), *P. austriacus*/*auritus*, and a **cross-family** confusion pair not previously flagged here — *Miniopterus schreibersii* vs *Pipistrellus pygmaeus*.

Two operational notes worth carrying: BTO reports *P. nathusii* and *P. kuhlii* **combined** in their own projects rather than separating them; and *social* calls of that pair **can** be assigned to species with confidence where echolocation calls cannot — the same social-calls-outperform-echolocation pattern already recorded for *Miniopterus* in the Central America batch.

## 2. *Coelops frithii* — Taiwan's first record, and an HDC/LDC exception

Full parameters recovered: narrowband component FME **90.6 ± 2.0 kHz** (first harmonic, 0.5 ± 0.3 ms), then an FM sweep **194 → 113 kHz**, duty cycle **7.7 ± 2.8%** (87 sequences, 425 calls).

This is a genuine exception to a dichotomy used throughout this project. High duty cycle echolocation is otherwise confined to Rhinolophidae, Hipposideridae and *Pteronotus parnellii*. *C. frithii* is a hipposiderid — ostensibly HDC — yet consistently uses **low** duty cycle whether roosting, flying, or approaching a fluttering target. The authors argue the LDC strategy is *derived from* HDC ancestors. Behaviourally it still acts HDC: it approached fluttering targets 40.4% of the time versus **0%** for sympatric *Myotis*, and comparably to sympatric HDC species (*H. armiger* 53.3%, *R. monoceros* 56.7%).

It also **adjusts its harmonic content** — the second harmonic of the narrowband component appears at 180–200 kHz, most obviously in stationary bats. More support for `harmonic_n` as a first-class field.

And another extreme detectability case: calls were "barely detectable when the microphone was within 50 cm of the bat" — joining *Cloeotis percivali* (<1 m) and *Furipterus horrens* (<2 m).

## 3. Kerivoulinae bandwidth

*Kerivoula pellucida* buzz calls start at **250 kHz** — the source calls it the most broadband and highest-pitched tonal animal vocalization known. Across 7 species, bandwidths of 78–170 kHz at 140–200 calls/s, with the paper's core finding being that these gleaners **break the usual trade-off**, maximising bandwidth *and* repetition rate simultaneously on approach. Independently corroborates the Borneo batch's *K. hardwickii* result.

## Not reached

*Phauk et al. 2013* (Cambodia) and the Vietnam urban-bats paper remain unfetched, as does the swarming-*Myotis* cepstral paper. They stay on the v2 checklist under Tier C.

## Where this leaves things

The open queue is now essentially exhausted. Everything of consequence that remains is behind the GBIF API, a binary file format, a paywall, or a bot wall — all of which need your machine. The single highest-value item is unchanged: **the seven ABCD GBIF datasets**, which would fix Indonesia, Cambodia and Yunnan in one script.

Worth noting what this round actually produced: not many new numbers, but **three false gap claims overturned and one over-strong "not separable" flag qualified.** At this stage of the project, correcting what's already recorded is yielding more than adding rows.
