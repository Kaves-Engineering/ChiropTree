# South America — batch 4: Peru (final Andean/Pacific sub-batch)

189 Chiroptera species (Pacheco et al. 2021, full named checklist obtained). **20 species with direct primary Peruvian measurements**, plus **67 more reachable only as region-general proxies** from earlier batches. Combined: **87/189 = 46.0%** — but those two numbers mean different things and the files keep them separate.

Files: `peru_bats_full_list.csv` (the checklist itself), `peru_call_records.csv` (93 records, the 20 primary species), `peru_coverage_audit.csv` (all 189 species, marked covered/missing, and for covered ones, `basis` = primary vs. regional proxy), `peru_sources.csv`.

## How the checklist was actually obtained — worth recording as a method

Peru's authoritative list (Pacheco et al. 2021, 573 mammal species, 189 bats) has the same problem Colombia's did: the paper's body text gives family/order counts, not the full species list. But an R package, **perumammals** (Santos Andrade & Gonzales Guillén 2025, on CRAN and GitHub), packages the checklist's Annex 1 as build data for an R data-validation tool. Its GitHub repo's build script (`data-raw/DATASET.R`) revealed the raw source: an Excel file at `data-raw/anexo_1_pacheco_etal_2021.xlsx`. My bash tool's allowed domains include `raw.githubusercontent.com`, so I fetched that Excel file directly and parsed it with `openpyxl` — 189 named bat species with full taxonomy, common names, ecoregions and endemism flags, no manual transcription required.

This is worth remembering as a general technique: when a country's official checklist is locked in a binary format (Colombia's Darwin Core ZIP, for instance), check whether anyone has built an R or Python package around it — those packages' build scripts often reveal a plain-text or spreadsheet source sitting in a public GitHub repo, reachable even when the original publisher's site is not.

## Family coverage

| Family | Covered/Total |
|---|---|
| Emballonuridae | 10/14 |
| Furipteridae | 1/2 |
| Molossidae | 18/30 |
| Mormoopidae | 4/5 |
| Noctilionidae | 2/2 |
| Phyllostomidae | 38/107 |
| Thyropteridae | 0/4 |
| Vespertilionidae | 14/25 |

Thyropteridae is a clean zero — consistent with the family-wide statement already documented in the Brazil batch that three of five *Thyroptera* species have literally no published echolocation description anywhere.

## The primary Peruvian data: a genuinely strong dedicated source

Ugarte-Núñez (2020) covers 20 species from the arid southwestern departments (Arequipa, Moquegua, Tacna) — coastal desert and western Andean slopes, an ecosystem type barely represented in any other batch of this project. Real means, SDs, and pulse counts, ranging from n=3 (*Eumops perotis*, flagged as too small to trust) to **n=3,100** (*Myotis atacamensis*) — the largest single-species sample size anywhere in this entire project.

## Findings

**A genuine, citable taxonomic disagreement between two Peruvian sources, not a project error.** Ugarte-Núñez (2020) calls the widespread Andean long-eared bat *Histiotus montanus*. Pacheco et al. (2021) — the authoritative national checklist, published the following year — places the same species (same author citation, "(Philippi & Landbeck, 1861)") in *Eptesicus*, as *Eptesicus montanus*. Two serious, recent, in-country sources disagree on the genus. Both retained in the record; the disagreement itself is now documented rather than silently resolved one way or the other.

**A clean structural summary the source states explicitly**, directly usable for the ChiropTree page: the 20 species split into two acoustic design clusters. Broadband descending-FM callers with large bandwidth — Vespertilionidae and Furipteridae (no harmonics) plus Phyllostomidae (harmonics, with an overlap pattern that tracks diet: nectarivores' harmonics barely overlap, frugivores' overlap heavily, and the sanguivore *Desmodus rotundus* has the most complex pulse of all, with an added FQC segment on the first harmonic). Versus narrowband FQC callers — exclusively Molossidae, itself split into convex-pulse alternators (*Molossus*, *Promops*) and non-alternating concave/uninflected callers (the other eight molossids here).

**Restricted-range and threatened species are disproportionately well described here**, because that was the point of the study: *Lasiurus arequipae* (described 2020), *Eumops chiribaya* (described 2014), *Amorphochilus schnablii*, *Mormopterus kalinowskii*, and *Platalina genovensium* — all named in the source's own abstract as targets specifically because they are rare or narrowly distributed. Acoustic survey is doing real conservation work here, independent of its taxonomic-identification value.

**One value is very likely a transcription error, flagged rather than fixed.** *Nyctinomops aurispinosus* duration is reported as 13.40 ± 51.69 ms — a standard deviation nearly four times the mean, on a bounded positive quantity. Left in the record with a note; do not use until checked against the original table image.

**A cross-batch consistency check surfaced an apparent conflict, not necessarily an error.** *Nyctinomops macrotis* peak frequency here is 17.43 kHz; the Jung et al. 2014 primary value already in the South America batch-1 file gives start/end frequencies of ~28.8/16.7 kHz for the same species. These aren't the same parameter (peak vs. start/end), so they may both be correct, but it's exactly the kind of pairing that deserves a side-by-side check when you rebuild this locally.

## The regional-proxy layer, and why it's kept separate

67 additional species get a value only by reusing Brazilian Amazon (Yoh et al. 2020), region-general South American (Arias-Aguilar et al. 2018 SA-Tr), or Central American (Arias-Aguilar CA-Tr, Jung et al. 2014) measurements for the same species. Given that this project has now repeatedly shown several-kHz geographic variation within single species across South America (*Myotis riparius*, *Lasiurus blossevillii*, rhinolophid CF frequencies in the Old World batches), these values should be understood as "a value for this species exists somewhere in the Neotropics," not as Peruvian data. `peru_coverage_audit.csv` marks every one of these with `basis = regional proxy` specifically so they're never confused with the 20 primary rows.

## Verification status

Zero verified rows, consistent with every batch to date.

## South America tranche status

All four Andean/Pacific sub-batches are done: Brazil/Amazon, Ecuador, Colombia, Peru. Remaining for South America as a whole: the Southern Cone (Argentina, Chile, Bolivia, Paraguay, Uruguay) and the Guianas + Venezuela.
