# Africa — batch 4: West & Central Africa

Fourth African batch, covering the Sahelian and Upper Guinean zones. **9 species/taxa, 25 records** — the thinnest African batch so far, and the reason is a genuine and important asymmetry in the literature rather than a limitation of this search.

Files: `africa_westcentral_call_records.csv`, `africa_westcentral_sources.csv`.

## The structural problem with West Africa

Every previous African batch was anchored on a purpose-built regional call library: Swaziland (20 species), Kenya high-duty-cycle bats (8 species), Zambia (22 species). **No equivalent exists for West Africa.** The anchor here is a five-species preliminary study from Cameroon whose own authors describe it as a *start* toward a national reference library, and which states directly that "acoustic survey has never been used to characterize and identify echolocation calls of bats anywhere in Cameroon."

For a region running from Senegal to Cameroon and holding some of the continent's richest bat faunas — the Upper Guinean forests and the Congo Basin fringe — the accessible acoustic literature amounts to scattered single-country studies. This is consistent with the ChiroVox statistic recorded in the East Africa batch: the main open global call library includes exactly **one** African country (Liberia).

## Findings

**Two cryptic lineages that acoustics separates where morphology cannot.** At Mount Nimba (Guinea/Liberia/Côte d'Ivoire), *Hipposideros* lineages C1 and E1 overlap in both external and cranio-dental measurements — but call at clearly different frequencies, 145–150 kHz versus 127–128 kHz. This is the inverse of the usual pattern in this project, where morphologically distinct species prove acoustically inseparable. Here the calls are the *more* diagnostic character. The authors are explicit that sample sizes were small.

**The Sahelian *Scotophilus* pair is the worst-separated species pair in any African batch.** Discriminant analysis classified *S. dinganii* correctly only 52.6% of the time, with 47.4% of its calls assigned to *S. leucogaster*. Their group centroids sit almost on the same point in discriminant space — despite a clear forearm-length difference (49–57 mm vs 43–51 mm). Overall five-species accuracy was 69.7% against a 33.3% chance baseline.

**The same species calls higher in the Sahel than in southern Africa.** Both *Scotophilus dinganii* and *Mops condylurus* show frequency parameters "generally higher" in Far North Cameroon than in KwaZulu-Natal, Durban, Soutpansberg and Swaziland. The authors attribute this to method (hand-release), habitat clutter, detector distance and humidity rather than biology — but the practical consequence is the same as in every other region of this project: **a southern African reference library will misjudge Sahelian recordings of the same species.**

**Three first-published Anabat records for Africa** — *Mops niveiventer*, *Chaerephon major* and *Scotophilus leucogaster* — with call-shape descriptions captured but numeric values locked in an unretrievable table object.

## Limitations, stated plainly

- **The anchor paper's main data table was not retrievable.** Table 2 of the Cameroon study holds descriptive statistics for all ten measured parameters across five species; it is a table object absent from the fetched text. Only the values restated in the narrative (two species) plus the complete DFA accuracies were captured. The PDF at `link.springer.com/content/pdf/10.1186/s41936-018-0041-7.pdf` would supply it.
- **The Mount Nimba data came via a ResearchGate table extract**, not the publisher — all four of those records are marked `extraction_confidence: medium`, and sample sizes were not captured.
- **Tanshi et al. 2021 (Nigeria, ten new country records) was never independently fetched.** One value from it reaches this dataset only through a citation inside another source's table. It is very likely the single richest unexploited West African acoustic source identified so far.
- **No modern West African species checklist was obtained.** The only regional monograph identified is Rosevear (1965) — sixty years old, predating essentially all acoustic work and most modern taxonomy.

## Africa running total

| Batch | Region | Species |
|---|---|---|
| 1 | Southern Africa (Eswatini/South Africa) | 24 |
| 2 | East Africa (Kenya) | 10 |
| 3 | Zambia (south-central) | 22 (14 new) |
| 4 | West & Central Africa | 9 (7 new) |
| | **Unique African species covered** | **53** |
| | Continental total | 379 |

Remaining: North Africa, and Madagascar + Indian Ocean islands (excluded from the sub-Saharan database entirely, with a highly endemic fauna and at least one dedicated acoustic survey already identified — Kofoky et al. 2009).

## Verification status

Zero verified rows, consistent with every batch in this project.
