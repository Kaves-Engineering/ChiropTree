# Central Asia & the Middle East — echolocation call records (batch 5 of 5 for Asia)

Kazakhstan, Uzbekistan, Turkmenistan, Kyrgyzstan, Tajikistan, Iran, Iraq, Israel, Jordan, Lebanon, Syria, Saudi Arabia and the Gulf states, Turkey. This closes out the Asia continent, and it is the thinnest batch of the tranche by ingested data — **2 real quantitative records** — while surfacing the clearest evidence in the whole project that better data is sitting one retry away.

Files: `camena_call_records.csv`, `camena_sources.csv`.

## The one that got away

Hackett, Holderied & Korine 2017 describes 15 species from the Arava rift valley, Israel — cited repeatedly by the Vietnam, China and Korea reviews earlier in this Asia tranche, meaning it is recognised across the field as a foundational regional reference. It is genuinely open: an author-accepted-manuscript PDF is hosted directly by the University of Bristol's repository, with 947 recorded downloads. This pipeline's fetch tool hit a bot-detection block on the PDF specifically, while the same host's abstract/metadata page for the identical record fetched cleanly seconds earlier. **This is a confirmed-open, confirmed-relevant, not-yet-retrieved source** — the exact URL is in `camena_sources.csv`, and a different fetch approach (a real browser, a short delay, a different user-agent) would very likely succeed where this pass didn't.

What the abstract alone establishes is worth recording: the paper describes **4 species using 6 call types that appear to actively separate their frequencies to minimize overlap** — the authors frame this as a case of acoustic character displacement. Every other multi-species overlap finding in this entire project (Rhinolophidae in Bulgaria, *Nyctalus*/*Tadarida* in Europe, *Myotis* everywhere) has described *unresolved* overlap that acoustic methods can't cleanly separate. This is the first candidate case of species actively evolving *away* from each other's frequencies rather than simply happening to differ or happening to overlap — a genuinely different phenomenon, and worth flagging specifically for follow-up.

The same abstract states the Arava community "is also found in other Middle Eastern deserts including the deserts of Jordan, Syria and Saudi Arabia" — meaning this single Israeli study, once retrieved, would cover acoustic identification for a large fraction of the entire Arabian and Levantine desert bat fauna at once.

## Iran: a 420-page monograph with acoustic data buried inside it

Benda et al. 2012, part of a systematic multi-decade "Bats of the Eastern Mediterranean and Middle East" monograph series, states explicitly that it analyses "426 calls from 68 call sequences" as part of its 420-page account of Iran's bat fauna — at least 902 distribution records across 50 species and 8 families. This is a real, open, substantial primary source with real acoustic content, and only its existence and scale were confirmed this pass; the acoustic subsection itself was not located within the retrieved excerpt. The same series has a Part 9 covering Transcaucasia and West Turkestan — meaning **much of Central Asia may already be covered by this exact series**, under a part number not yet searched for.

## The two records actually ingested

- ***Eptesicus bottae*** peak frequency 32.5 kHz, from Holderied et al. 2005 — a nice, unplanned illustration of how this project's continent-by-continent structure can misfile a species. The same primary measurement was already cited in this project's South America batch, reached there only because a taxonomically adjacent paper mentioned it in passing. It is only now, in this batch, attached to the species' actual home region.
- ***Rhinopoma hardwickii*** terminal frequency 32 kHz (range 18–80), sourced via a curated numbers database rather than a primary paper — flagged as needing verification against whatever primary source the database itself drew from.

## Central Asia: a genuine, total gap

No acoustic source for Kazakhstan, Uzbekistan, Turkmenistan, Kyrgyzstan or Tajikistan was found. Real taxonomic and distributional work continues in the region — a 2021 paper on a mummified Iranian bat specifically discusses a living Kazakhstani population of the same species complex — but nothing describing echolocation calls turned up. Stated plainly rather than papered over.

## Verification status

Zero verified rows, consistent with every batch in this project.

## Asia tranche: complete

This closes all 5 proposed Asia sub-batches: South Asia, Mainland Southeast Asia, Maritime/Insular Southeast Asia, East Asia, and Central Asia & the Middle East. Across the tranche, the strongest pattern is structural rather than species-level: the best sources are almost always single comprehensive national or regional reviews (South Asia's Srinivasulu et al. 2025, Vietnam's Győrössy et al. 2024, China's López-Bosch et al. 2021, Borneo's McArthur & Khan 2021, Israel's Hackett et al. 2017) rather than accumulations of many small studies — and in three of five sub-batches (China, this batch, and partially Vietnam), the single biggest ceiling on this project's coverage was not the absence of a good source but this pipeline's inability to open a paywall, a bot-detection wall, or a binary spreadsheet that a human researcher with normal institutional or browser access could open directly.
