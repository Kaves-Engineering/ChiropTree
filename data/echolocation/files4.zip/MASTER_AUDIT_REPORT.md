# Master audit report — full project, all regions

Requested audit of every batch collected to date (Denmark through the five Asia sub-batches). This supersedes the Asia-only audit from the previous turn; all fixes below are already applied to the underlying files.

## Scope of this audit

51 CSV files, 16 README/report documents, roughly 2,300 individual data rows, across 15 completed batches: Denmark, Europe, North America, Central America + Mexico, Colombia, Ecuador, Peru, Brazil/Amazon, Australia/NZ, and five Asia sub-batches. Not yet started: the Southern Cone, Guianas + Venezuela, and all of Africa.

## Issues found and fixed

**1. Genus-column bug (Vietnam file).** 35 of 88 rows (40%) had a subfamily or tribe name instead of the true genus. Checked every other file with a `genus` column project-wide (Peru's was clean). Fixed by deriving genus from each binomial; the file now yields exactly 28 unique genera, matching the source paper's own stated count for the first time.

**2. Non-species rows using the species-name field.** Beyond the Borneo case you'd already flagged, found the same pattern in Central America, Peru, and South America/Amazon files — study-level or family-level findings stored with a descriptive phrase in `sci_name` instead of a real binomial, inflating a naive species count by 1 in each of four files. All six instances found project-wide are now bracket-tagged (`[STUDY-LEVEL NOTE]`, `[FAMILY-LEVEL NOTE]`, etc.) and excluded from species counts. One downstream fix: Central America's corrections document claimed "37 species" for a file that actually has 36 real species plus one such note-row; the doc now says 36.

**3. Undated `unknown_no_data` claims.** Nine rows across four files lacked the `last_searched` date this project requires for any claim of absence. Checked each individually rather than blanket-fixing: eight had a genuine, specific basis (a named source's explicit statement, or a search I actually ran) that simply predated when this project started requiring the field — backfilled with the correct date. The ninth is the original example/template row from the very start of this conversation, already self-labeled "EXAMPLE," left as-is since it was never a real claim.

**4. Orphaned source citation.** `S-AA18` (Arias-Aguilar et al. 2018) was cited in three South America files but only ever defined in the Central America sources file — anyone using the South America files alone would hit an undefined citation. Added the missing definition to both South America sources files.

**5. Coverage-percentage drift (Australia).** The README stated 27/81 = 33.3%, but the audit CSV itself, recomputed from scratch, gave 28/82 = 34.1% — an extra species (*Mormopterus beccarii*, correctly flagged as not part of the original 81-species checklist) was inflating the file's own denominator. Fixed by marking that row's status distinctly so it's excluded from the computed percentage; the file now recomputes to exactly 27/81 = 33.3%, matching the prose.

## Checked and confirmed clean

- **No duplicate record IDs** anywhere across all 51 files.
- **`evidence_class` vocabulary** (11 values used ~2,300 times project-wide) has no typos or near-duplicate variants.
- **`access` vocabulary** in source files (10 values) and **`source_status`** in data files (3 values) are both clean and consistently applied.
- **Every remaining `source_key` reference** now resolves within its own batch's sources file.
- **Spot-checked six additional README headline claims** (Denmark, Europe, North America, Central America, Colombia, South Asia) against their underlying files — all matched exactly.

## The two deliverables you specifically requested

**`PAYWALL_AND_ACCESS_REGISTRY.csv` / `.md`** — every restricted-access source across the whole project (25 total), tiered by what's actually worth chasing first. Tier 1 (7 sources) are confirmed open and confirmed relevant but blocked only by this pipeline's specific tool limits — a real browser or local Python session should get every one of them, including the single highest-value target in the entire project: four supplementary data files for China's echolocation review, linked directly from the publisher, that would likely take China from near-zero to the best-covered country in Asia. Tier 2 (10 sources) are genuinely paywalled and need institutional access. Tier 3 (11 sources) are secondary citations never independently chased, mostly just species-count references. A "method note" section records three specific tricks that worked this project (government mirrors, R/Python package build scripts revealing binary checklists, university repository manuscripts) for reuse.

**`GLOBAL_SPECIES_GAP_TALLY.csv` / `.md`** — deliberately does not give one global percentage, because the underlying data quality varies too much for that to be honest. Nine regions have a genuine name-by-name audit; across those, **407 species are confirmed missing** out of 739 checked (44.9% missing). A separate Tier 2 table covers regions with only a partial or estimated denominator — Mexico (69 species, all recorded, zero values extracted), Colombia (222-species count known, roster never obtained), most of Southeast Asia and East Asia (single-country data standing in for a whole sub-region), and three areas not yet started at all (Southern Cone, Guianas + Venezuela, Africa). The document states plainly that the true global gap is almost certainly much larger than 407, since the audited regions are disproportionately the better-studied parts of the world.

## What's still unaudited

This pass covered structural/mechanical correctness (IDs, vocabularies, citations, arithmetic) very thoroughly. It did not re-verify the *content* of individual measurements against primary sources — that remains exactly where it was: zero rows project-wide have `verified_by` filled in, and that's still the right state per this project's own rule (nothing renders publicly until a human checks it).
