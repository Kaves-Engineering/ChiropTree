# Plan: preparing this dataset for cross-species comparative analysis

## How the field actually does this

I checked the primary literature rather than assuming. Four recent studies asking exactly your kind of question — Thiagavel et al. 2017 (*Sci Rep*, 86 vespertilionids), Leiser-Miller & Santana 2021 (*Ecol Evol*, phyllostomids), Castro et al. 2024 (*BMC Ecol Evol*, 314 species), Conenna et al. 2021 (*GEB*, 1,058 species) — all converge on the same three-step recipe:

1. **Test for phylogenetic signal first** — Pagel's λ (or Blomberg's K) on each call parameter, via `phytools::phylosig` in R.
2. **If signal is present (it always is — λ ≈ 0.86–0.92 for peak frequency in every study above), you cannot use ordinary regression or ANOVA.** Species aren't independent data points; closely related species resemble each other by descent, not by ecology. This is Felsenstein's problem and it's non-negotiable.
3. **Use PGLS** — phylogenetic generalized least squares, fitted as a Pagel's λ model by REML, with the phylogeny as the covariance structure.

**The concrete implication for you: "correlation between frequency and genus" is not the right question as stated.** Genus *is* phylogeny. Any raw test would return a hugely significant result that tells you only that related bats are related. The publishable questions are: *does frequency scale with body size after controlling for phylogeny?*, *do nasal- and oral-emitters scale differently?*, *does a clade sit above or below the allometric prediction?* — which is precisely what Castro et al. 2024 did for 314 species.

## What you'd need that you don't have yet

| Requirement | Status | Where to get it |
|---|---|---|
| Species-level frequency | **286 species** with a single numeric value | ✅ have it |
| Phylogeny | ❌ missing | Upham et al. 2019 mammal tree, `vertlife.org/phylosubsets` — subset to Chiroptera, download 100+ trees to propagate uncertainty |
| Body size (forearm/mass) | ❌ missing entirely | PanTHERIA (CC0), Phylacine, EltonTraits; forearm length is the bat standard |
| Emission route (nasal/oral) | partial, in `call_type`/notes | Derivable at family level — it's the key moderator in Castro et al. 2024 |
| Foraging guild | partial | Several batches recorded it; needs harmonising |

Body size is the single biggest missing piece. Without it there is no allometry analysis at all, and PanTHERIA is a free download.

## The blocking problem you must fix first

**186 of 304 species have more than one numeric peak-frequency value, and for 47 species those values disagree by more than 20 kHz.** Worst cases: *Choeroniscus minor* spans 41–122 kHz, *Tonatia saurophila* 22–102 kHz.

These are **not** measurement noise. Looking at the records, they're three distinct problems stacked:

1. **Different harmonics reported as if the same trait.** Barataud's French Guiana data reports FME on the fundamental *and* on H1, H2, H3 separately. A phyllostomid's fundamental at 31 kHz and its H1 at 66 kHz are the same call. Pooling them is meaningless. **This alone explains most of the 47.**
2. **Different parameters conflated.** `characteristic_frequency` (Anabat, flattest part), `fmaxE` (frequency of maximum energy), `peak_frequency`, `resting_CF` (Doppler-compensating bats at rest) — 32 distinct frequency-like trait names in the data. These are genuinely different measurements, not synonyms.
3. **Real biological and methodological variation** — the geographic and recording-context effects this project documented repeatedly.

Averaging across these would produce a clean-looking number that is scientifically meaningless. **This is the step where the analysis lives or dies.**

## Recommended plan, in order

**Step 1 — Build an analysis-ready species table (`ANALYSIS_species.csv`).** One row per species, with an explicit, documented aggregation rule:
- Filter to `trait ∈ {peak_frequency_kHz, fmaxE_kHz, frequency_of_max_power_kHz}` — the genuinely comparable set. **Exclude** characteristic frequency, resting frequency, knee frequency, and start/end/min/max.
- Keep only records where `harmonic` is the dominant/energy-richest one, or blank. Drop explicit H1/H2/H3 alternates.
- Restrict to `evidence_class = measured_primary` for the main analysis; run `measured_compiled` as a sensitivity check.
- Where multiple valid records remain, take the **median** and retain `n_sources`, `min`, `max`, `sd` as columns. Never discard the spread.
- Add `recording_context` as a categorical covariate — with 79% coverage it's usable, and this project has shown it matters by tens of kHz.

**Step 2 — Join the phylogeny.** Subset Upham et al. to Chiroptera at vertlife.org. **Taxonomy reconciliation is required first** — names in this dataset are as each source gave them (*Mormoops blainvillii*/*blainvillei*, subspecies trinomials in the Caribbean batch, `cf.` and `/` composites). Reconcile to the Mammal Diversity Database, which ChiropTree already uses. Expect to lose 10–20% of species to tip-matching failure.

**Step 3 — Join body size.** PanTHERIA for mass, targeted sources for forearm. Conenna et al. combined PanTHERIA + Phylacine + EltonTraits + EchoBank exactly this way.

**Step 4 — Run it.** In R: `phylosig()` for λ on each trait, then `caper::pgls` or `phylolm` with λ estimated by REML. Log-transform frequency and mass (all four studies do). Fit `log(PF) ~ log(mass) * emission_route`. Repeat across 100 trees from the credible set to propagate phylogenetic uncertainty.

**Step 5 — Interpret against known counterexamples.** This project independently documented three cases where body size does *not* predict frequency: *Pipistrellus kuhlii* ecomorphotypes (North Africa), *Molossus barnesi* calling lower than its larger congener (French Guiana), and *Macronycteris* sexes calling identically despite strong size dimorphism (Kenya). Those are the residuals worth looking at, not noise to explain away.

## What's realistically analysable now

- **286 species** with a numeric value, 230 of them `measured_primary`
- **20 families**, but only 6 with n ≥ 10 (Vespertilionidae 110, Phyllostomidae 45, Hipposideridae 31, Emballonuridae 24, Molossidae 24, Rhinolophidae 11)
- **27 genera with ≥ 3 species** — *Myotis* (36), *Hipposideros* (26), *Rhinolophus* (11), *Lasiurus* (9), *Kerivoula* (8)

After Step 1's filtering this will drop — probably to 200–240 species. That's still a real comparative dataset, comparable in size to Thiagavel et al. (86) and approaching Castro et al. (314).

## Two honest cautions

**Sampling is not phylogenetically random.** Coverage was driven by which regional call libraries happened to be open access. Aerial insectivores in temperate regions are heavily overrepresented; tropical gleaners and phyllostomids are underrepresented relative to their true diversity. That biases any clade-level comparison and should be stated as a limitation, not corrected away.

**Don't impute the 119 missing species.** Filling them by phylogenetic or allometric imputation and then testing for phylogenetic signal or allometry is circular — you'd recover the assumption you imputed with. Analyse complete cases and report the gaps.
