# South America — batch 5: Southern Cone (Argentina, Chile, Bolivia, Paraguay, Uruguay)

Fifth South American batch, completing the continent's regional coverage alongside Brazil/Amazon, Ecuador, Colombia and Peru.

**7 named taxa, 14 records.** This is the most paywall-constrained batch in the entire project: **every single primary source is behind a paywall.** Not one Southern Cone acoustic paper was retrievable in full.

Files: `southamerica_southerncone_call_records.csv`, `southamerica_southerncone_sources.csv`.

## The access situation, stated plainly

| Source | Status |
|---|---|
| Olmedo et al. 2026 — 16 Argentine species, acoustic ID key | Paywalled |
| González Noschese et al. 2024 — *Myotis dinellii* first description | Paywalled |
| Rodríguez-San Pedro & Simonetti 2013 — 4 Chilean species | Paywalled |
| Giménez et al. 2023 — 3 Patagonian *Histiotus* | Paywalled |
| González Noschese et al. 2025 — second Argentine paper | Paywalled, not fetched |

No institutional mirror, no preprint, no repository copy was found for any of them. The Zambia technique (institutional mirror) and the Peru technique (R package build script) both failed here.

**One concrete opening:** the Olmedo et al. supplementary material *is* openly hosted on Springer's media server even though the article isn't. Supplementary 1 is a DOCX that most likely contains the acoustic identification key itself; Supplementary 3–6 are four downloadable WAV recordings, one per family. My fetch returned the DOCX as unparseable binary, but a local download would open it in seconds. The exact URL is in the sources file. The authors also state all acoustic data is available on request.

## What was still extractable, and why it matters

**The highest species-level classification accuracy anywhere in this project: 99%.** Olmedo et al. report that aerial insectivores (Molossidae, Vespertilionidae, Noctilionidae) in northeastern Argentina classified at 99% by linear discriminant analysis. Set against the rest of the project: Chile 87.4%, Madagascar 82.2%, Cameroon 69.7%, Borneo 68% (forest vespers), Zambia 52.5–55.9%. The pattern that has recurred on every continent — aerial insectivores separate cleanly, clutter foragers do not — reaches its clearest expression here.

**Argentine phyllostomids may be more separable than Amazonian ones.** The same study got **74.5%** for phyllostomids. Compare Costa Rica (Leiser-Miller & Santana 2021) at 61.7% for taxonomic dietary guild, and the central Amazon (Yoh et al. 2020) where PCA found *no* separation by genus, subfamily or guild at all. Argentina sits at the depauperate southern margin of the phyllostomid radiation, with far fewer sympatric confusable species — a plausible mechanism, and one the tree page could show directly.

**A genuine Southern Cone endemic characterised for the first time.** *Myotis dinellii* occurs only in Bolivia and Argentina. Its calls — single harmonic, downward FM then downward QCF, 78.8 down to 39.6 kHz, 3.5 ms — were described for the first time in 2024 from 21 specimens in the Tucumán Yungas.

**Three Chilean vespertilionids share one call design.** *Histiotus montanus*, *Lasiurus varius* and *Myotis chiloensis* all use downward FM followed by narrowband QCF and are separable only on spectral detail, not structure. *Tadarida brasiliensis* stands apart with the longest duration and lowest frequencies of the four, not overlapping any of them.

**A morphology-vs-acoustics inversion, third occurrence.** A Chilean study at Pampa del Tamarugal reports that *Histiotus* body measurements were homogeneous across species while acoustic characters *were* identifiable for all four species present. That is the same pattern found at Mount Nimba in the West Africa batch and among Malagasy rhinonycterids — acoustics resolving what morphometrics cannot.

## Limitations

- **No named species checklist for any Southern Cone country was obtained**, so no coverage percentage is claimed. Barquez & Díaz (2020), the standard Argentine guide, and Sandoval et al. (2021) on Argentine species richness were both identified but not fetched.
- **Bolivia, Paraguay and Uruguay contribute nothing directly.** *Myotis dinellii*'s range includes Bolivia, but the recordings are Argentine.
- **The three Patagonian *Histiotus* species are inferred, not verified** — flagged medium confidence in the records.
- **An open Lucid identification key for Chilean bats exists** (Miller & Ossa 2021) and was not fetched; it is an interactive JavaScript key, browsable by a human but not by this pipeline. The same team's Honduras key is equally relevant to the Central America batch.

## South America: regional coverage complete

Brazil/Amazon, Ecuador, Colombia, Peru, Southern Cone. **Guianas + Venezuela remain** — Barataud et al. 2013 (French Guiana, 8 families) and Ochoa et al. 2000 (Venezuela) were both identified early in this project and never fetched.

## Verification status

Zero verified rows, consistent with every batch in this project.
