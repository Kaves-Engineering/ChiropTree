# Paywall & restricted-access registry — full project

Every source across all batches flagged as anything other than freely fetchable, consolidated for a rerun with institutional access or a real browser. Full machine-readable version: `PAYWALL_AND_ACCESS_REGISTRY.csv` (25 rows).

Six access categories are used project-wide:

| Status | Meaning | Count |
|---|---|---|
| `paywalled` | Confirmed behind a paywall on direct access | 9 |
| `paywalled_book` | A book chapter, not a journal article | 1 |
| `open_manuscript_blocked` | Genuinely open (author manuscript hosted by a university repository), but this pipeline's fetch was blocked by bot detection | 1 |
| `cited_not_retrieved` | Named and referenced by another source, but never independently searched for or fetched in this project | 11 |
| `open_unverified` | Reached via an intermediary (ResearchGate, a figure page) rather than the publisher; likely open but not confirmed | 1 |
| `not_found` | Searched for and not located at all | 2 |

## Tier 1 — highest priority: confirmed open, confirmed relevant, just not retrieved

These are not paywalled at all. They failed only because of this pipeline's specific tool limitations (bot detection, binary file formats, fetch token limits) — a normal browser or a local Python session will very likely get every one of these on the first try.

1. **Hackett, Holderied & Korine 2017** — *Echolocation call description of 15 species of Middle-Eastern desert dwelling insectivorous bats*, Bioacoustics 26(3). Author manuscript hosted openly by the University of Bristol (947 recorded downloads). Blocked by bot detection on direct PDF fetch. URL: `research-information.bris.ac.uk/files/155451945/Acoustic_identification_of_bats_in_the_Arava_desert.pdf`. **Covers 15 species from a desert community shared with Jordan, Syria and Saudi Arabia** — retrieving this one paper would materially improve the entire Middle East sub-batch.

2. **López-Bosch et al. 2021** — *Bat echolocation in continental China*, Mammal Research 66(3). Article body paywalled, but **four supplementary XLSX files are linked directly from the publisher and confirmed to exist**, unopenable only because they're binary spreadsheets: Table S1 (full per-species mean/SD/range for 7 call parameters), Table S2 (comparison data), Table S3 (regional knowledge index), Table S4 (publication counts, undescribed species flagged). URLs preserved in `eastasia_sources.csv`. **The single highest-value target in the entire Asia tranche** — would likely take China from near-zero to the best-covered country in the region.

3. **Pacheco et al. 2021 checklist Excel** (Peru) — solved during this project using the `raw.githubusercontent.com` route (see Method note below); flagging here only as a template for the same trick applied to:

4. **Ramírez-Chaves et al. 2025 / SiB Colombia Darwin Core Archive** (`ipt.biodiversidad.co/sib/archive.do?r=mamiferos_col&v=1.18`) — the full 222-species Colombian checklist, distributed only as a Darwin Core ZIP. Never successfully parsed. A local `unzip` + `csv` read would solve this in minutes.

5. **Srinivasulu et al. 2025 South Asia review, Supplementary Material 3** — the full 299-observation quantitative table; only the first ~181 records (roughly a third) were retrieved before this pipeline's fetch token limit truncated the document. A paginated or higher-limit fetch of the same open PDF (`threatenedtaxa.org`, article 9550) would complete it.

6. **Győrössy et al. 2024 Vietnam paper, Table S1** — directly linked downloadable spreadsheet with the full 87-species quantitative dataset; the narrative text was fetched but the actual data tables (rendered as images in the HTML) were not.

7. **South Asia checklist master Excel** (`threatenedtaxa.org/public/checklists/Bats_of_South_Asia_Checklist_v1_10_15Feb2026.xlsx`) — would resolve the 19-species numbering-gap ambiguity in that batch.

## Tier 2 — genuinely paywalled, needs institutional access

| Source | Batch | What it would add |
|---|---|---|
| Jones & Rayner (Behav. Ecol. Sociobiol.) | Europe (S14) | Second-harmonic structure basis for *Rhinolophus hipposideros* |
| Walters et al. 2012, iBatsID (J. Appl. Ecol.) | Europe (S15) | The paper establishing which European species are acoustically inseparable — currently only abstract-level findings used |
| Yovel, Geva-Sagiv & Ulanovsky (J. Comp. Physiol. A) | Europe (S18) | Primary source for *Rousettus aegyptiacus* click duration |
| Bats' echolocation of cryptic Iberian *Eptesicus* (Eur. J. Wildl. Res. 2015) | Europe (S29) | Full classification table for *E. isabellinus* vs *E. serotinus* |
| Teixeira & Jesus 2009 (Acta Chiropterologica) | Europe (S32) | Only numeric source for *Pipistrellus maderensis* and Madeiran *Plecotus austriacus* |
| Russ (ed.) 2021, *Bat Calls of Britain and Europe* | Europe (S26) | Only dedicated account for *Myotis crypticus* and *M. escalerai* |
| Jung, Kalko & von Helversen 2007 (J. Zool.) | Central America (S-JUNG07) | Primary source behind most Central American emballonurid rows, currently only used second-hand |
| Barclay et al. 1981 (Can. J. Zool.) | Central America (S-BARC81) | *Trachops cirrhosus* frog-hunting call intensity — conflicts with a newer open source, unresolved |
| Parsons 1997 (Can. J. Zool.) | New Zealand (S-NZ) | Full per-population quantitative table for both extant NZ species; only anchor FME values (28/40 kHz) currently held |
| Russ (ed.) 2021, ch. 8.15–8.16 | Same book as above | *M. crypticus* / *M. escalerai* dedicated accounts |

## Tier 3 — cited by another source, never independently searched for

11 sources across the project (full list in the CSV) — mostly national species-count references (Thailand, Laos, Cambodia, Indonesia, Philippines, Borneo-total, Japan mammal handbook, Mongolia bat taxonomy) picked up as citations inside other papers' reference lists but never themselves searched for or fetched. These are lower priority than Tiers 1–2 because in most cases they'd only refine a species-count denominator, not add call data.

## Method note for the rerun: three tricks that worked

1. **Government/university mirrors bypass publisher paywalls for guide-type documents.** *Bat Calls of New South Wales* was blocked at its original host but fetched cleanly from `environment.nsw.gov.au`. Always try a second search for "[title] pdf" before accepting a paywall.
2. **R/Python package build scripts reveal binary checklists' plain-text source.** Peru's checklist was blocked as a bank Excel file on its publisher site, but the `perumammals` R package's own GitHub build script (`data-raw/DATASET.R`) named the exact raw `.xlsx` path, fetchable directly via `raw.githubusercontent.com` and parsed with `openpyxl`. Check for an R/Python package wrapping any blocked national dataset before giving up on it.
3. **Author-manuscript repositories (university IR pages) often host the same paper openly.** Works for metadata/abstract pages reliably; PDF-specific bot detection (as with Hackett et al. 2017 above) is the main remaining obstacle — worth a real browser session rather than an automated fetch.
