# Africa — batch 5: North Africa (Tunisian Sahara anchor)

Fifth and final mainland African batch. **7 species, 57 records**, from a single well-documented Tunisian Saharan expedition.

Files: `africa_northafrica_call_records.csv`, `africa_northafrica_sources.csv`.

## The biogeographic result, quantified

North Africa is conventionally described as Palearctic rather than Afrotropical. This batch tests that against the project's own accumulated data, and the split is absolute:

- **Overlap with the four sub-Saharan African batches (Eswatini, Kenya, Zambia, West/Central Africa): zero species.** Not one of the 56 species recorded across sub-Saharan Africa appears here.
- **Overlap with the Europe batch: four of seven species** — *Tadarida teniotis*, *Eptesicus isabellinus*, *Pipistrellus kuhlii*, *Plecotus gaisleri*.

For ChiropTree, this means North Africa should almost certainly join the European/Palearctic assemblage rather than the African one. The Sahara is the faunal boundary, not the Mediterranean.

The remaining three species are the genuinely Saharan element: *Asellia tridens*, *Otonycteris hemprichii*, and *Taphozous nudiventris*.

## A hypothesis tested and rejected — worth recording as a negative result

*Pipistrellus deserti* was long treated as a separate desert species until genetic work showed it to be only an ecomorphotype of *P. kuhlii marginatus* — smaller and lighter. The authors predicted that the size difference should produce a distinct acoustic signature, since body size and call frequency correlate across many bat genera.

**Both principal component analysis and Gaussian mixture models failed to find it.** Across 1,940 measured calls, bandwidth ranged 0–58.3 kHz and FMAXE 36.9–49.5 kHz — but the variation tracked *site*, not morphotype. All five call parameters differed significantly among the four sites (Kruskal–Wallis, all highly significant), with start frequency higher at Ain Rhziza and FMAXE differing everywhere except between the two Bordj el Khadra sites.

This is a clean published negative: a real within-species body-size difference did **not** produce a detectable acoustic split, while habitat did. It cuts directly against the size-frequency allometry invoked repeatedly elsewhere in this project.

## The software problem, third independent appearance

*P. kuhlii*'s FMAXE here is higher than anywhere else in the species' Mediterranean range — higher than Italy, Pantelleria, Greece, Malta, the Near East, Jordan, Syria, northern Algeria, and even northern Tunisia. Only central Algeria is comparable, and the northern Algerian Sahara reports higher still, where another team *did* claim to separate the two ecomorphotypes.

The authors' own explanation is worth quoting in substance: the discrepancy "could be due to differences in sound analyses, which would require the analyses to be performed again by a unique operator."

That is the third time in this project that two credible sources have disagreed about the same species for reasons of measurement method rather than biology — after the Zambia batch (SonoBat automated vs. BatSound manual) and the West Africa batch (hand-release vs. free-flight). It is becoming one of the most consistent findings across the whole effort.

## Other findings

**A first national record made acoustically.** *Taphozous nudiventris* was identified in Tunisia for the first time from its calls alone — long QCF multiharmonic, FMAXE 23.17 ± 0.80 kHz measured at the **second harmonic**. Prior Maghreb records were from owl pellets. The paper provides a three-country comparison (Tunisia / Jordan / Near East) that makes this one of the better-triangulated species in the whole project.

**Desert bat faunas are genuinely impoverished, not just under-sampled.** The Sahara holds 22–26 species total, and only 11 in the core desert, none endemic. Seven species from one week's work is a third of Tunisia's entire 21-species fauna.

## Limitations

- **One week, one country, one season.** The authors note that *Rhinopoma cystops* and *Vansonia rueppellii*, both known from central Tunisia, were simply not recorded.
- **Identifications rest on an unpublished sound library** (R. Dalhoumi's Tunisian reference collection), which is not accessible.
- **Morocco, Algeria, Libya and Egypt contribute nothing directly.** The key Moroccan reference (Disca et al. 2014, 16 species) and the foundational Algerian paper (Ahmim et al. 2020, explicitly "the first bioacoustics prospection of the bats of Algeria") were both identified but not fetched — the latter is paywalled.
- **The Benda et al. monograph series is the big untapped body of work.** Parts covering Egypt, Libya, Jordan, Sinai and Syria all contain echolocation data and are all cited by this batch's anchor. The same series was flagged in this project's Central Asia & Middle East batch. Collectively it likely covers most of North Africa and the Middle East and remains almost entirely unexploited here.

## Africa: complete (mainland)

| Batch | Region | Species |
|---|---|---|
| 1 | Southern Africa | 24 |
| 2 | East Africa (Kenya) | 10 |
| 3 | Zambia | 22 (14 new) |
| 4 | West & Central Africa | 9 (7 new) |
| 5 | North Africa | 7 (7 new) |
| | **Unique African species** | **60** |
| | Continental total | 379 |

**Madagascar and the Indian Ocean islands remain** — excluded from the sub-Saharan database entirely, with a highly endemic fauna and at least one dedicated acoustic survey already identified (Kofoky et al. 2009, *Acta Chiropterologica*, forest bats of Madagascar).

## Verification status

Zero verified rows, consistent with every batch in this project.
