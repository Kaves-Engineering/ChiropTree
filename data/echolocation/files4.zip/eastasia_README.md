# East Asia — echolocation call records (batch 4 of 5 for Asia)

China, Taiwan, Japan, Korea, Mongolia. This batch has the widest gap yet between "a source exists and is named" and "the data is actually in the CSV" — the flagship China review is paywalled with its data locked in binary supplementary files whose exact download URLs I can hand you, but not open.

**Korea: 14 of 21 species, real peak-frequency ranges from open-access text. China: review-level statistics only (64/135 species = 47.4% documented, per the review's own count) — zero per-species numeric values ingested, but the primary data's exact location is fully documented for a local rerun.** Japan, Taiwan and Mongolia are named-source-but-unfetched or outright gaps.

Files: `eastasia_korea_call_records.csv`, `eastasia_china_summary.csv`, `eastasia_sources.csv`.

## China: the clearest "acquisition target" of this entire project

López-Bosch et al. 2021 (*Mammal Research*, paywalled — confirmed via direct fetch, `meta-access: No`) is structurally the same kind of paper as South Asia's and Vietnam's reviews in earlier batches: a systematic review of 130 studies (1999–2020) yielding parameters for 64 of 135 species (47.4%), an identification key covering 114 species (84.5%) to species or phonic-group level, and a "Bat Knowledge Index" flagging northwestern China as the most under-studied region — directly parallel to South Asia's Echolocation Knowledge Ratio and Indonesia/Borneo's detectability findings in earlier batches.

Unlike the Vietnam and South Asia papers, the article body itself is paywalled. But **four supplementary data files are linked directly from the publisher page and confirmed to exist** — Table S1 (full Chinese species data, mean±SD and range for seven call parameters), Table S2 (non-China comparison data used to build the key), Table S3 (per-region Bat Knowledge Index scores), Table S4 (per-species publication counts, with undescribed species flagged in bold in the original). Their exact URLs are preserved in `eastasia_sources.csv`. My fetch tool retrieves them as unparseable binary; a local machine with Excel or a Python `openpyxl` session (the same technique that rescued the Peru checklist in an earlier batch) would very likely take China from the current near-zero to the best-covered country in this entire batch in a single step.

## Korea: real data, real findings

Fukui, Hill, Kim & Han 2015 (open access, full text fetched) measured 1,129 pulses from 93 individuals across 14 of Korea's 21 known species. Two findings stand out:

**A textbook geographic cline, broken by islands.** *Rhinolophus ferrumequinum* peak frequency decreases from west to east across East Asia — Beijing 75.1 kHz, Jilin 69.6, the Korean peninsula 67.8–69.5, Kyushu and western Honshu 67–69, Hokkaido 63–66 — a clean continental gradient compiled from five separate studies. But Jeju Island's population sits at 72 kHz, distinctly higher than the mainland Korean peninsula immediately across the strait, and Tsushima Island (Japan) shows the same upward break. The paper's own explanation, citing Yoshino et al. 2008: CF frequency is maternally transmitted, so restricted female dispersal on islands lets frequency drift away from the mainland cline. A geographically precise, mechanistically explained exception to a well-documented rule.

**The worst- and best-classified species in the same genus.** Discriminant function analysis correctly classified *Myotis bombinus* over 90% of the time — it has an unusually broad bandwidth (71.4–113.1 kHz) that sets it apart — while *M. petax* was correctly classified only 22.6% of the time, mainly confused with *M. ikonnikovi* and *M. macrodactylus*. Same genus, same study, same recording protocol: one species escapes the usual *Myotis* identification problem on a single distinctive parameter, the rest don't.

## What's missing

- **Japan**: Two dedicated sources are named and cited repeatedly by both the Korea and China reviews — Fukui, Agetsuma & Hill 2004 (8 species, Hokkaido) and Funakoshi 2010 (13 species, Kyushu, in Japanese) — neither fetched this pass.
- **Taiwan**: No checklist or dedicated call source was searched for or found, despite Taiwan's *Hipposideros terasensis* Doppler-shift-compensation work being cited in multiple papers across this entire Asia tranche, and Taiwanese institutions (National Taiwan Normal University) co-authoring the Vietnam batch's flagship paper.
- **Mongolia**: A single Mongolian-language source states 20 Vespertilionidae species (15% of the country's mammals) — likely close to the true country total given Mongolia's vespertilionid-dominated fauna, but not confirmed as such, and no echolocation source was found at all.

## Verification status

Zero verified rows, consistent with every batch in this project.

## Asia tranche status

4 of 5 Asia sub-batches done. One remains: Central Asia & the Middle East.
