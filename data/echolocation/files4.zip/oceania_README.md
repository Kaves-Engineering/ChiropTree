# Oceania — echolocation call records (batch 1: Solomon Islands & New Guinea)

New Guinea, the Solomon Islands, Bougainville, and — not yet reached — Fiji, Vanuatu, New Caledonia, Samoa, Micronesia and Hawai'i. This is the last major region in the project to be started.

**Solomon Islands: 14 of 21 possible echolocating species with real reference-call data (67%), one of the highest completion rates achieved anywhere in this project.** New Guinea: fragmentary but real, from three separate sources. The wider Pacific (Fiji, Vanuatu, New Caledonia, Micronesia, Hawai'i) has nothing this batch — a genuine, stated gap.

Files: `oceania_solomon_call_records.csv` (138 records, 28 taxa), `oceania_png_call_records.csv` (6 records), `oceania_sources.csv`.

## The anchor source is exceptional

Pennay & Lavery 2017, fully fetched, is comparable in quality to the best sources anywhere in this project — the NSW Australia guide, the Bornean call library, the French Guiana monograph. A complete quantitative table (7 parameters, 18 species/forms), full narrative accounts, a working identification key, and — critically — **explicit, named lists of every unidentified call type and every species with genuinely no reference calls at all**. Nothing is silently missing; every gap is a stated finding.

## Findings

**Two hipposiderids show large, non-overlapping frequency splits within one small archipelago.** *Hipposideros diadema* calls at 59 kHz in the west (matching PNG and Australia) but a clean, non-overlapping 66 kHz in Guadalcanal — closer to Javan populations 2,000+ km away than to its own neighbouring islands. *H. cervinus* shows the same pattern: 139 kHz on Makira, 147 kHz on Guadalcanal. The guide asks the question directly rather than resolving it: is this habitat-driven plasticity, or cryptic taxonomic variation hiding within named species? Both splits sit at the edge of what call data alone can settle — exactly the kind of case this project has flagged repeatedly, from Rhinolophus in South Asia to Hipposideros in Kenya.

**A genus converging on another genus's frequency band.** *Aselliscus tricuspidatus*'s Guadalcanal "low form" (114–116 kHz) overlaps almost entirely with the unrelated *Hipposideros calcaratus*. Two different genera in the same family landing on the same band is a pattern this project has now seen in Kenya (*H. coxi*/*Emballonura*) and Borneo — this is its clearest within-family expression yet.

**A megabat producing structured ultrasound with no evident echolocation function.** *Melonycteris woodfordi*, a pteropodid, was recorded making long (40–60 ms) multiharmonic ultrasonic trills while foraging at flowering trees — audible to observers as bird-like trilling, but with ultrasonic content the guide's authors flag as unusual and unstudied. This is a third documented case in this project of a non-echolocating megabat producing structured ultrasound, after the tongue-click echolocation of *Rousettus aegyptiacus* (Europe batch) and *R. leschenaultii* (Mainland SE Asia batch) — but those were echolocation; this looks like something else entirely, possibly social communication, and is a genuinely open question the source itself raises.

**Detectability bias, stated as policy rather than just observed.** The guide tells its own future users directly: species calling above 100 kHz may only be detectable within a couple of metres, and rarity of detection does not mean rarity of the animal. This is the same finding as Kenya's *Cloeotis percivali* (<1 m) and Borneo's *Hipposideros coxi*, but here it's written as explicit guidance for the next researcher rather than a post-hoc observation.

## New Guinea: fragmentary, but genuinely sourced

Three sources, none complete, all honestly bounded:

- **Leary & Pennay 2011** covers 8 species with 744 reference sequences from PNG's 57 known microchiropteran species, but only the abstract was retrievable — species identities were not resolved, so this batch records a study-scope placeholder rather than guessing which 8 species were covered.
- **The Pharotis imogene voucher paper** gives the first-ever call description for one of the world's least-known mammals, plus incidental characteristic-frequency values for two species also recorded in the Solomon Islands (*Aselliscus tricuspidatus* 112–113 kHz mainland vs. 115–119 kHz island-dependent; *Hipposideros cervinus* 136.5–138 kHz mainland, closest to the Solomons' Makira population) — a genuine cross-batch comparison point, flagged rather than merged since the mainland values are characteristic frequency and the Solomons values are peak frequency.
- **The Mt Wilhelm elevational transect** (open bioRxiv preprint) confirms species richness declines with elevation and that even five months of combined mist-net and acoustic survey recovered only ~30% of the estimated regional species pool — a concrete, quantified illustration of how far from complete any tropical bat inventory typically is.

## What's missing

- **Fiji, Vanuatu, New Caledonia, Samoa, Micronesia, Hawai'i: nothing.** No acoustic source was searched for or found for any of them this pass. Hawai'i in particular has a single, well-studied endemic subspecies (*Lasiurus semotus*, the Hawaiian hoary bat) that very likely has published call data — a clear next target.
- **No named checklist was obtained for New Guinea or the wider Pacific** — only the Solomon Islands (14 confirmed + 7 suspected = 21) has a real, source-stated denominator.
- **Leary & Pennay 2011's full text** would resolve 8 named PNG species with real data.

## Verification status

Zero verified rows, consistent with every batch in this project.
