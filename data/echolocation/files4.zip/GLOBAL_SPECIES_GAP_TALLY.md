# Global species gap tally — how many bat species still lack echolocation data

The honest answer has two tiers, and collapsing them into one number would misrepresent the project. Full machine-readable version: `GLOBAL_SPECIES_GAP_TALLY.csv`.

## Tier 1 — regions with a genuine name-by-name audit (checklist obtained, every species individually checked)

| Region | Species with any data | Denominator | % | Confirmed missing |
|---|---|---|---|---|
| Denmark | 13 | 17 | 76.5% | 4 |
| Europe | 32 | 47 | 68.1% | 15 |
| North America (US/Canada) | 40 | 45 | 88.9% | 5 |
| Ecuador | 32 | 171 | 18.7% | 139 |
| Peru | 87 | 189 | 46.0% | 102 |
| Brazil | 99 | 186 | 53.2% | 87 |
| Australia | 27 | 81 | 33.3% | 54 |
| New Zealand | 2 | 3 | 66.7% | 1 |
| **Sum** | **332** | **739** | **44.9%** | **407** |

**407 species across these eight audited regions are confirmed, by name, to have no echolocation call data retrieved in this project.** This is the only number in this whole tally that can be stated with real confidence, because it's the only one built by checking every species individually against a real checklist rather than estimating.

Two of these regions have unusually strong caveats worth repeating: Peru's 87 "covered" species include 67 that are not Peru-specific data at all, only region-general Neotropical proxies reused from Brazil — the Peru-specific number is really 20/189 (10.6%). Ecuador's 171-species denominator is itself one to three checklist versions behind the current 178–182, so its true percentage is very slightly lower than stated.

## Tier 2 — regions with a real denominator but no full audit, or no audit at all

These regions have *some* number attached to them, but it isn't the same kind of number as Tier 1, and averaging it in would be misleading.

| Region | Denominator | What's actually known | Why it's not a full audit |
|---|---|---|---|
| Mexico | 69 (Sonozotz) | All 69 have real recordings; **zero have retrieved numeric values** — locked in a Dryad deposit and a JS web app | Full species list, zero extracted data |
| Central America (excl. Mexico) | ~146 (estimated) | 69 species touched | Denominator is a summed country-total estimate, not a real regional checklist |
| Colombia | 222 (real count) | 8 species, real primary data | The 222-species roster itself was never obtained as names — only the count |
| South Asia | 155 | 87 species cited by the source review as having *some* data; only 18 have numeric values actually extracted here | Relies on the review's own count rather than an independent species-by-species check |
| Mainland SE Asia | 129 (Vietnam only) | 88 species call-type classified; 5 with full numbers | Myanmar, Thailand, Laos, Cambodia: **zero** species-level data |
| Maritime/Insular SE Asia | 99 (Borneo only) | 31 species, real quantitative data | Indonesia (likely the single largest national fauna in this project, 175–200+) and the Philippines (~79+): **zero** |
| East Asia | 156 (China+Korea) | Korea: 14 real; China: 64 *cited* as having data, **zero numeric values retrieved** | China's actual numbers are in paywalled/binary files, not in this dataset |
| Central Asia & Middle East | not established | 2 species | Essentially a blank region |
| Southern Cone | not established | 0 | Batch not started |
| Guianas + Venezuela | not established | 0 | Batch not started |
| Africa | not established | 0 | Continent not started |

## The one honest global statement this project can make

**At minimum, 407 named species have no echolocation data, confirmed by direct audit against real checklists, across the nine regions where that audit was actually done.** Given that those nine regions are disproportionately the *better-studied* parts of the world (Europe, North America, Australia, the temperate/accessible parts of South America), and that several entire continents and megadiverse countries (Indonesia, the Philippines, Colombia, most of mainland Southeast Asia, all of Africa, most of Central Asia) have either no audit or no data at all, **the true global figure is certainly much higher than 407** — plausibly in the range of 700–900 of the world's ~1,470 bat species, though this project cannot currently support a precise number above the audited 407.

The right way to state this on the ChiropTree page is almost certainly the Tier 1/Tier 2 split above, not a single global percentage — a single number would either understate the true gap (if computed only from audited regions) or overstate this project's rigor (if computed by treating estimated denominators as equal in quality to real ones).
