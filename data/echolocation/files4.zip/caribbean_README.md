# Caribbean — echolocation call records (batch 1)

Cuba, Hispaniola (Dominican Republic, Haiti), Jamaica, Puerto Rico, the Lesser Antilles, Trinidad & Tobago, the Bahamas. **23 taxa, 30 records.** No named regional checklist was obtained this batch — flagged plainly, same treatment as Colombia and Africa's West/Central batch earlier in this project.

This batch has an unusual shape worth understanding before using it: **every substantial primary source is either paywalled or was confirmed open but blocked by bot detection.** Nothing here came from a clean, uninterrupted fetch. What's genuinely useful survived through abstracts, species accounts, and — in two cases — values that surfaced only because a *different*, unrelated paper quoted them directly.

Files: `caribbean_call_records.csv`, `caribbean_sources.csv`.

## The best-documented finding: a phyllostomid that switches acoustic strategy entirely

*Phyllonycteris poeyi* (Cuba, Dominican Republic, Haiti) is the clearest single-species story in this batch, and it survived the paywall because three independent later papers all quote the original finding directly. Flying in the open, it emits long (up to 7.2 ms), intense, **single-harmonic** calls under 50 kHz — the first documented case of a phyllostomid concentrating energy in the first harmonic, which is normally filtered out in this family's vocal tract. Detectable at 15+ metres, consistent with 20 km nightly commutes and flight recorded above 100 m altitude. Flying in enclosed spaces, the *same species* switches to short, low-intensity, multiharmonic FM calls typical of every other phyllostomid.

This is the most concrete example in this whole project of a species crossing between two of the acoustic categories used throughout — narrowband/CF-like versus broadband multiharmonic FM — based on immediate flight context rather than fixed identity. *Phyllops falcatus*, a second Cuban phyllostomid, shows a related but distinct exception (unusual first-harmonic frequency range); its full citation could not be resolved and is flagged for follow-up rather than guessed.

## An inter-island frequency split in a single genus

*Erophylla sezekorni* (Bahamas, Cuba, Jamaica, Cayman Islands) calls several kHz higher than its sister species *E. bombifrons* (Hispaniola, Puerto Rico), and places maximum energy on the second harmonic rather than the first. The exact values sit in a table this pipeline could not fully retrieve, but the direction and existence of the split is confirmed by the source text. This is the same phenomenon as *Noctilio leporinus*'s structural difference across French Guiana, Martinique and Guadeloupe in the previous South American batch — island populations of Caribbean bats keep turning up real, if incompletely quantified, acoustic divergence.

## A confirmed-open source blocked purely by bot detection

Jennings et al. 2004 — 119 bats, 12 species, Puerto Rico/Dominica/St Vincent — is the flagship regional paper for the Lesser Antilles and northeastern Caribbean, and BioOne's own metadata page confirms it is open access. Three separate fetch attempts (the direct URL, the BioOne download endpoint, and a ResearchGate mirror) all returned automated bot-challenge pages instead of content. This is the same category of failure as the Middle East paper in an earlier batch: **not a paywall, a retrieval problem**, and worth a real browser session rather than another automated attempt.

## The single richest untapped source in the Caribbean

Pio et al. 2010 covers 29 species across 5 families in Trinidad, with 12 phyllostomid species described acoustically for the first time and a discriminant analysis spanning 11 species individually and 6 foraging guilds. It is comparable in ambition to the French Guiana and Vietnam papers that anchored two of this project's best batches — but it is fully paywalled, and only one value escaped: *Chiroderma villosum*'s duration (1.4 ± 0.3 ms) and peak frequency (91.8 ± 5.8 kHz), recovered only because an unrelated Costa Rican paper happened to quote it directly. This is worth remembering as a general technique — a paywalled source's numbers sometimes leak into later open papers that cite them.

## A caution about this batch's own construction

During the search for the Trinidad paper, a Colombian savanna emballonurid study surfaced in the same results (different authors, different country, different species — *Saccopteryx*, *Peropteryx*, *Rhynchonycteris*) and was briefly and incorrectly attributed to Pio et al. 2010 before being caught. It was excluded and is not in the dataset. Recorded in the sources file as a caution for any future audit of this batch specifically, since the two papers' abstracts were interleaved in the same search response.

## What's missing

- **No acoustic source for Jamaica** was identified at all.
- **The Cuban mormoopid community study** (4 species, real fieldwork) is paywalled with only qualitative findings recovered — no per-species numeric parameters.
- **No named regional species checklist.** The Caribbean's true bat diversity across these territories was not established as a denominator this batch.
- **The Bahamas paper's citation is incomplete** — author names, volume and year were not resolved from available search results, only a ResearchGate identifier. Flagged rather than fabricated.

## Verification status

Zero verified rows, consistent with every batch in this project.
