# Deep search for the missing regions — findings

A targeted search of the largest remaining gaps: Indonesia (~200+ species, zero records), Venezuela (~174, zero), Thailand, Cambodia, the Philippines, Taiwan, Peninsular Malaysia. **19 new sources located.** One fully fetched and ingested; the rest documented with DOIs and access status.

Files: `deepsearch_malaysia_call_records.csv` (26 records, 9 taxa — new data), `deepsearch_new_sources.csv` (19 sources, tiered).

## The single biggest find: the Asian Bat Call Database

There is a GBIF-funded programme — **ABCD, the Asian Bat Call Database** — run out of the Hungarian Natural History Museum (Görföl & Csorba) with SEABCRU (Kingston) and Joe Chun-Chia Huang, that has already published national bat **call** datasets as Darwin Core occurrence records on GBIF, with taxonomy vetted by Gábor Csorba.

Their own project statement is the exact problem this project kept hitting:

> "call descriptions from over 40% of the 270 echolocating species have been reported in literature, but **none of the recordings are accessible** and many of the species occurrences attached are not published."

ABCD exists specifically to fix that. Datasets found, all with DOIs:

| Dataset | Covers | DOI |
|---|---|---|
| **MZB Indonesian bat call library** | Java, Maluku, Sulawesi, West Papua | `10.15468/vytnyb` |
| **Bats of Bukit Barisan Selatan** | Sumatra | `10.15468/emgg92` |
| **Echolocating bats of West Java** | West Java | GBIF `fa9940cd-…` |
| **HNHM Asian Bat Database** | Malaysia, **Cambodia**, Vietnam, **Yunnan** | `10.15468/zkfx5b` |
| Bats of Penang Island | Malaysia | `10.15468/tn7zxw` |
| Insectivorous bats of Langkawi | Malaysia | GBIF `bifa04-24-21` |
| Bats of northeastern Vietnam | Vietnam | GBIF `6814e124-…` |

**I could not retrieve any of it.** `api.gbif.org` is not in this container's network allowlist, and `www.gbif.org` bot-blocks the fetch tool. Both are trivial for Claude Code — `rgbif` or a plain API call. Between them these cover Indonesia (this project's single largest gap), Cambodia and Yunnan (both currently zero), and add to Malaysia and Vietnam.

## Ingested this session: Peninsular Malaysia

**Heller 1989**, found as an open archive.org scan and fetched in full. 8 species, 6 genera, Ulu Gombak near Kuala Lumpur. Peninsular Malaysia was a genuine gap — the previous Maritime SE Asia batch was Borneo-only.

Three findings worth having beyond the numbers:

**A mechanistically different explanation for frequency alternation.** *Hesperoptenus blanfordi* alternates two call types 8 ± 1.5 kHz apart. Heller argues this is far too large for the Doppler-compensation explanation applied to emballonurid alternation (2–3 kHz), and instead computes that atmospheric attenuation (1.2 dB/m at 40 kHz vs 0.7 dB/m at 32 kHz) gives the low calls ~30 m range against ~20 m for the high ones — i.e. **two call types for two detection ranges**. Frequency alternation appears in this project on five continents; this is the first source offering a quantitative alternative mechanism.

**Two more allometry counterexamples.** *H. blanfordi*'s low call type (31–37 kHz) sits well below the ~40 kHz its body size predicts from European vespertilionid allometry. And across six *Taphozous* species, call frequency vs forearm length regresses to **r = 0.04** — completely flat — which Heller contrasts explicitly against the strong negative relationship in *Rhinolophus*, *Hipposideros* and other vespertilionid genera. Published in 1989, and it lines up with the independent counterexamples this project found in North Africa, French Guiana and Kenya.

## Other high-value targets located

- **Mexico (Orozco-Lugo et al. 2013, Therya 4:33–46, `10.12933/therya-13-103`)** — 11 aerial insectivorous species with described pulses. **Therya is fully open and this project has fetched it successfully before.** Mexico currently has 69 species listed with *zero* numeric values, so this is the best value-to-effort item on the list.
- **Venezuela (Ochoa, O'Farrell & Miller 2000)** — abstract confirms **30 species identified acoustically** across 15 genera and 5 families, 19 verified by capture-and-release. Venezuela is currently zero. Paywalled at BioOne.
- **Thailand (Hughes et al. 2011 + its 2010 CF-family companion)** — 19 species, 510 calls, four call types with per-type DFA accuracies. Thailand is currently zero. Paywalled.
- **Cambodia (Phauk, Phen & Furey 2013)** — *Cambodian Journal of Natural History* is open access; a direct PDF search should get it. Cambodia is currently zero.
- **Vietnam urban bats (Diversity 13:18)** — MDPI, fully open, 4 species. Not fetched only for time.
- **Taiwan (*Coelops frithii*, PLoS ONE, open on PMC)** — an ostensibly high-duty-cycle hipposiderid that consistently uses a **low** duty cycle: 7.7 ± 2.8%, narrowband component at 90.6 kHz then an FM sweep 194→113 kHz. A documented exception to the HDC/LDC dichotomy used throughout this project.
- **Kerivoulinae (Schmieder et al. 2010, Biology Letters, open on PMC)** — *Kerivoula pellucida* buzz calls reach 250 kHz, described as the most broadband and highest-pitched tonal animal vocalization known. Corroborates the Borneo batch independently.

## What this search did not find

- **The Philippines** — no dedicated acoustic source surfaced despite targeted searching. Still zero.
- **Japan, Mongolia, Central Asia** — nothing new.
- **Guyana, Suriname, Jamaica** — nothing new.

## The honest summary

The gaps are mostly **not** because the science is missing. For Indonesia, Cambodia, Yunnan, Thailand, Venezuela and Mexico, the data demonstrably exists — and for the ABCD datasets it exists in structured, DOI-cited, machine-readable form on GBIF. Every one of them was blocked by an access mechanism (network allowlist, bot detection, or paywall) rather than by absence of research. That is a materially different conclusion from "these regions are unstudied," and it should be stated that way anywhere this dataset's coverage is described.
