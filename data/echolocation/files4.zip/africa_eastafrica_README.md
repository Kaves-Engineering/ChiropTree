# Africa — batch 2: East Africa (Kenya anchor)

Second African batch. East Africa (Kenya, Tanzania, Uganda, Rwanda, Burundi) has **145 species** — the richest documented bat fauna on the continent, with Kenya alone at 108, Tanzania 105 and Uganda 98.

**This batch covers 10 species with real primary data — about 7% of the regional fauna.** That number is low, and it is low for a specific and honest reason: the anchor source is deliberately a *partial* guide, covering only the high-duty-cycle constant-frequency families (Hipposideridae and Rhinonycteridae). No comprehensive East African call library exists.

Files: `africa_kenya_call_records.csv` (73 records, 10 species), `africa_eastafrica_sources.csv`.

## The anchor source and what it does not cover

Webala, Rydell, Dick, Musila & Patterson 2019 (*Journal of Bat Research & Conservation*, open access, full text and all three tables fetched) covers 8 species recorded across 24 named Kenyan localities, 2013–2018, with Pettersson full-spectrum detectors and voucher specimens deposited at the National Museums of Kenya. Data are sex-disaggregated and separated by recording context (hand-held resting frequency vs. flight-cage vs. free-flying).

The paper states its own scope limitation plainly: *"There is no comprehensive guide to the echolocation calls of Kenyan or East African bats."* What exists was collected over many years with very different equipment, is of variable quality, and is scattered across publications. This batch inherits that limitation directly.

## Findings

**The highest constant frequency of any bat known.** *Cloeotis percivali* calls at 217–225 kHz in Kenya. Southern African populations sit at 208–213 kHz — slightly lower, possibly two forms — and since the species was named from a specimen near Mombasa, the Kenyan calls likely represent the typical condition. There is a brutal detectability consequence the paper spells out: extreme atmospheric attenuation at that frequency gives a **maximum recording range of under 1 metre**, so the species is essentially invisible to passive acoustic monitoring. This is the most extreme detectability case in this entire project, exceeding even *Hipposideros caffer*'s 0.3 m from the Swaziland batch.

**Two first-ever call descriptions.** *Doryrhina camerunensis* is described acoustically here for the first time anywhere — long pulses (23–28 ms) at ~51 kHz, so unlike other hipposiderids that the authors note its calls resemble *Rhinolophus* more than *Hipposideros*. *Hipposideros beatus* is recorded from Kenya and East Africa for the first time.

**Sexual dimorphism in call frequency that is decoupled from body size — twice, in opposite ways.** *Triaenops afer* is cleanly bimodal by sex (females 82–84 kHz, males 70–75 kHz), and the authors note the sexes are similar in body size, so size does not explain it. Conversely, *Macronycteris gigas* and *M. vittata* are strongly sexually size-dimorphic (forearm differences of 7–9 mm) yet the sexes within each species use the *same* frequency. Two adjacent genera in the same families, showing that size and call frequency are independent in both directions. Historical data reproduced as Table 3 makes this quantitative.

**A within-species geographic frequency difference large enough to look like a different species.** *Hipposideros beatus* calls at 114–124 kHz in Kenya but 139–147 kHz in Ivory Coast — a ~20 kHz gap, attributed to a recognised subspecies difference. *Doryrhina cyclops* shows ~8 kHz between Uganda (51.4) and West Africa (59.7). The paper's explicit conclusion is that local call libraries are essential and continental generalisations are unsafe — the same lesson this project has now hit in Europe, South America, Asia and Australia.

**A species with no described calls anywhere in the world.** *Hipposideros megalotis* (Kenya, Somalia, Eritrea, Ethiopia) was not encountered, and the source states directly that its echolocation calls remain undescribed. Recorded here as `unknown_no_data` on the strength of a specialist source's explicit statement — the strongest possible basis for that label.

## What's missing

- **~135 of East Africa's 145 species have no data in this batch.** Everything outside Hipposideridae and Rhinonycteridae — all Vespertilionidae, Molossidae, Rhinolophidae, Emballonuridae, Nycteridae, Pteropodidae — is untouched.
- **No named species checklist for East Africa was obtained.** The Patterson & Webala 2012 key (145 species) and the Musila et al. 2019 annotated Kenyan checklist both exist and were identified; neither was fetched. Same gap as the Southern Africa batch and Colombia.
- **A December 2025 Uganda preprint** (open, on bioRxiv) covering free-flying bats at six southwestern Uganda sites was identified but not fetched. Its own introduction contains a striking statistic worth recording: ChiroVox, the main open global call library, includes **only one African country** (Liberia), and commercial auto-ID classifiers cover regions representing just **7–8% of the world's ~1,500 bat species**.
- **The Zambian call library** (22 species, 238 individuals, 2025, open access) has now been identified and deferred in *both* African batches. It is the most-deferred African source in this project.

## Verification status

Zero verified rows, consistent with every batch in this project.

## Africa status

2 of an expected 5–6 African sub-batches done (Southern Africa, East Africa). Remaining: West Africa, Central Africa, North Africa, and Madagascar + Indian Ocean islands (excluded from the sub-Saharan database entirely, and with a highly endemic fauna). Combined African coverage so far: **34 species** against a continental total of 379.
