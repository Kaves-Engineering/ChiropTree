# Master consolidation — how to use this dataset

The project accumulated **43 data files, 37 different schemas, 95 distinct column names, and not one column present in every file.** That's fine for building batch-by-batch and useless for auditing or lookup. These four files replace that for day-to-day use. The originals stay put as provenance.

## The four files

| File | Rows | What it's for |
|---|---|---|
| **`MASTER_call_records.csv`** | 2,857 | Every measurement, one unified schema. The thing to query. |
| **`MASTER_species_index.csv`** | 499 | One row per species. The thing to look things up in. |
| **`MASTER_sources.csv`** | 169 | Every source, with how many records depend on it. |
| **`MASTER_audit_worksheet.csv`** | 763 | Only the rows a human actually needs to check, prioritised, with blank verdict columns. |

## Recommended workflow

**To look something up:** `MASTER_species_index.csv`. One row per species with the best available frequency, duration, low/high frequency, call type, which regions it appears in, how many sources back it, and — importantly — the evidence class of that best value. 380 of 499 species have a frequency value.

**To audit:** `MASTER_audit_worksheet.csv`, top down. It contains 763 rows (27% of the data) — the ones carrying a flag or resting on weaker evidence. **The other 73% are clean `measured_primary` rows from open, fully-fetched sources and don't need a first-pass human check.** Four blank columns (`CHECK_verdict`, `CHECK_by`, `CHECK_date`, `CHECK_note`) are there to fill in. Sorted by priority, then by how many records depend on the same source — so fixing one entry high on the list often resolves many rows at once.

**To trace provenance:** every master record keeps its `record_id`, `region_batch`, and `source_key`. Join to `MASTER_sources.csv` for the citation and access status, or open the original batch file named in `region_batch`.

## What the consolidation itself found

Merging surfaced three real problems that were invisible while the data sat in separate files:

1. **One row had `evidence_class` and `source_key` transposed** (a Caribbean record). Fixed, flagged in notes.
2. **South Asia used literal citation strings where every other batch used source keys** — 181 rows pointed at things like `"Wordley et al. 2014"` instead of a key, which meant 14 phantom "sources" and no way to join. Fixed: the primary study is preserved in the notes as `[PRIMARY STUDY: ...]`, and `source_key` now points to the review that compiled it, with `source_status = compiled_via_review`.
3. **13 undated `unknown_no_data` claims had reappeared** in batches written after the earlier audit fixed the same bug. Backfilled and flagged. This bug class has now recurred **three separate times** in this project — it's worth a permanent validation check rather than another manual sweep.

Orphaned source keys after these fixes: **none**.

## The evidence hierarchy, unchanged

Sort or filter on `evidence_class` — this is the field that carries the project's honesty:

```
measured_primary          1,894   read from a study that made the recordings
measured_compiled           528   from a review/compilation of primary work
value_exists_unretrieved    284   a real measurement exists; I couldn't extract it
identification_threshold     62   a classifier decision boundary, NOT a distribution
unknown_no_data              50   searched by species name, nothing found (all dated)
field_key_only               19   heterodyne tuning band, not comparable to peak frequency
inferred_family/genus        18   propagated from a relative, never measured
not_separable                 1   value cannot exist — species not acoustically distinguishable
```

The distinction that matters most for publication: **`identification_threshold` is not a measurement.** Sixty-two rows, mostly European, are classifier decision boundaries tuned so classes don't overlap. They look like measurements and aren't.

## Three rules to keep

- **Nothing has been verified by a human.** Every `verified_by` is empty across all 2,857 rows. That's accurate, not an oversight. Don't publish a `measured_*` value as fact until that column is filled.
- **`value_exists_unretrieved` ≠ `unknown_no_data`.** The first is an acquisition task (see `CLAUDE_CODE_CHECKLIST.md`), the second is a scientific claim about the literature. Never render them the same way.
- **Recording context can move a value 20–50 kHz.** Release calls, hand-held calls and free-flying calls are not interchangeable; this project documented same-species discrepancies traceable purely to method, and to analysis *software* (SonoBat vs BatSound) in at least three independent regions. `recording_context` is populated wherever the source stated it.

## Still open

- `CLAUDE_CODE_CHECKLIST.md` — 99 blocked sources, sorted by what tool unblocks them. Tier 1 is 8 open-access binary files that would roughly double measured coverage.
- `GLOBAL_SPECIES_GAP_TALLY.md` — 407 species confirmed missing across 739 audited, but only 9 regions have a true name-by-name audit. Colombia and Africa (Tier 1 items 3 and 4) would add ~490 species to that denominator.
- Taxonomy is **not** reconciled to a single backbone. Names are as each source gave them, which means synonyms and subspecies-vs-species inconsistencies persist across regions (e.g. *Mormoops blainvillii*/*blainvillei*, *Hipposideros commersoni* vs *Macronycteris vittata*). Reconciling to the Mammal Diversity Database — which the ChiropTree site already uses — should happen before any join to the tree.
