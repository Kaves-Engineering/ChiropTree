import csv

# Region: (denominator, denominator_source, covered, covered_meaning, audit_quality)
REGIONS = [
 ("Denmark", 17, "Naturstyrelsen 2013, named", 13, "measured or compiled value", "FULL AUDIT (named checklist, every species checked)"),
 ("Europe", 47, "EuroBaTrait/HME, named", 32, "measured_primary or measured_compiled (16+16)", "FULL AUDIT"),
 ("North America (US/Canada)", 45, "NABat-derived, named", 40, "measured_compiled (SonoBat tables)", "FULL AUDIT"),
 ("Mexico", 69, "Sonozotz, named", 0, "0 with retrieved VALUES (69 have real recordings, values locked in Dryad/Selia)", "FULL LIST, ZERO VALUES RETRIEVED"),
 ("Central America (excl. Mexico)", 146, "Country totals summed, NOT a named checklist (estimate)", 69, "at least one record, any evidence_class", "NO NAMED CHECKLIST — denominator is an estimate"),
 ("Colombia", 222, "GBIF/SiB 2025, count only, NOT retrieved as names", 8, "measured_primary (Arevalo-Cortes 2024)", "NO NAMED CHECKLIST — denominator is a real count, roster unavailable"),
 ("Ecuador", 171, "Tirira 2018.1, named (current edition likely 178-182)", 32, "measured_primary/compiled/proxy, taxonomy-resolved", "FULL AUDIT (denominator 1-3 versions stale)"),
 ("Peru", 189, "Pacheco et al. 2021, named", 87, "20 primary + 67 regional-proxy", "FULL AUDIT (67 of the 87 are NOT Peru-specific data)"),
 ("Brazil", 186, "Garbino et al. 2024, named", 99, "measured_primary or measured_compiled, taxonomy-resolved", "FULL AUDIT"),
 ("Southern Cone (Argentina/Chile/Bolivia/Paraguay/Uruguay)", None, "NOT YET ATTEMPTED", 0, "-", "BATCH NOT STARTED"),
 ("Guianas + Venezuela", None, "NOT YET ATTEMPTED", 0, "-", "BATCH NOT STARTED"),
 ("Australia", 81, "Wikipedia/AFD, named", 27, "measured_primary, taxonomy-resolved (NSW only)", "FULL AUDIT (NSW source only - geographic, not random, gap)"),
 ("New Zealand", 3, "Named, complete", 2, "measured_primary (1 species genuinely unrecordable)", "FULL AUDIT - effectively complete"),
 ("South Asia", 155, "Srinivasulu et al. 2025/26, named (138 of 155 independently verified by name)", 87, "cited by the source review as having ANY data (only 18 have extracted numeric values here)", "SOURCE-LEVEL AUDIT, not independently re-verified species by species"),
 ("Mainland SE Asia (Vietnam only; Myanmar/Thailand/Laos/Cambodia = 0)", 129, "Gyorossy et al. 2024, named (Vietnam only)", 88, "call-type classified; only 5 have full numeric values", "VIETNAM-ONLY - other 4 countries have ZERO species-level data"),
 ("Maritime/Insular SE Asia (Borneo only; Indonesia/Philippines/Timor-Leste/Singapore = 0)", 99, "Phillipps & Phillipps 2016, Borneo only", 31, "measured_primary, full quantitative", "BORNEO-ONLY - Indonesia (likely 175-200+ species) and Philippines (~79+) have ZERO species-level data"),
 ("East Asia (China + Korea only; Japan/Taiwan/Mongolia = 0)", 156, "China 135 (Lopez-Bosch 2021) + Korea 21 (Yoon 2010)", 78, "China: 64 cited by review (0 numeric values retrieved); Korea: 14 with real ranges", "CHINA REVIEW-LEVEL ONLY, no per-species numeric data retrieved; Korea has real data"),
 ("Central Asia & Middle East", None, "NOT ESTABLISHED", 2, "2 species, both cross-referenced from other batches", "NEAR-TOTAL GAP - no checklist, no dedicated retrieved source"),
 ("Africa", None, "NOT YET ATTEMPTED", 0, "-", "CONTINENT NOT STARTED"),
]

with open("/mnt/user-data/outputs/GLOBAL_SPECIES_GAP_TALLY.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["region","denominator","denominator_source","species_with_any_data","what_counts_as_covered","audit_quality"])
    for row in REGIONS:
        w.writerow(row)

# Compute the honest headline numbers - ONLY for regions with a FULL AUDIT
full_audit = [r for r in REGIONS if "FULL AUDIT" in r[5] and r[1] is not None]
tot_denom = sum(r[1] for r in full_audit)
tot_covered = sum(r[3] for r in full_audit)
print("=== Regions with a genuine name-by-name audit ===")
for r in full_audit:
    print(f"  {r[0]}: {r[3]}/{r[1]}")
print(f"\nSUM across audited regions only: {tot_covered}/{tot_denom} = {100*tot_covered/tot_denom:.1f}%")
print(f"Species explicitly confirmed MISSING in audited regions: {tot_denom - tot_covered}")

print("\n=== Regions with NO real audit or NO data at all ===")
for r in REGIONS:
    if "FULL AUDIT" not in r[5]:
        print(f"  {r[0]}: denominator={r[1]}, quality={r[5]}")
