# Gap-fill round 1 — results of steps 1–4

Executed the strategy: clear the "source exists" cases, re-mine held sources, run genus-level searches, mine bibliographies. **Two new datasets ingested, four new sources located, one prior decision independently vindicated.**

New files: `mexico_morelos_call_records.csv` (39 records, 11 species), `genus_search_call_records.csv` (7 records).

## Step 1 — "Source exists, not extracted": Mexico cleared

**Orozco-Lugo et al. 2013 fetched in full** and it's the single best result of this round. Mexico previously had 69 species listed from Sonozotz with **zero numeric values**. It now has real, primary, search-phase parameters for 11 species from the Sierra de Huautla dry forest.

Two things worth noting about *how* it was retrieved: the publisher DOI was unreachable, but the **open Redalyc mirror** worked on the first try. That's a fourth retrieval technique to add to the list (after government mirrors, R-package build scripts, and institutional repositories) — **Latin American open-access aggregators: Redalyc, SciELO, mastozoologiamexicana.org.**

The scientific payoff includes a genuine correction:

***Eumops underwoodi* is not unrecordable after all.** Every previous batch in this project recorded it as `unknown_no_data`, on the strength of the Sonozotz project explicitly listing it among species they could not record (roosts inaccessible, forages hundreds of metres up). Orozco-Lugo et al. recorded it: **FMAXAM 16 kHz, 20 ms pulses, audible to humans**, alternating high/low pulses 2.4 kHz apart, two harmonics with the first as fundamental. A "structurally unrecordable" call turns out to be recordable — worth remembering before accepting any similar claim elsewhere in the dataset.

***Mormoops megalophylla*** also moves from `value_exists_unretrieved` (North America batch) to measured: FMAXAM 52 kHz on the second harmonic, 7 ms.

**And a documented within-sequence harmonic switch.** *Pteronotus personatus* puts most energy in the second harmonic's FQC in 60% of pulses — but in the other 40% switches to the **first** harmonic's FQC. *P. davyi* does the same thing in only 8% of pulses. This is direct empirical support for treating `harmonic_n` as a first-class field rather than a note: for this species, no single harmonic assignment is correct for the whole sequence.

The source also independently reproduces the recording-context warning this project has hit repeatedly — the authors explicitly call for standardised protocols because their own mixed contexts (enclosure / hand-release / free-flight) inflate apparent variation, and they attribute a *Mormoops* duration discrepancy against Yucatán data (7 ms vs 4 ms) specifically to the Yucatán recordings being made in an enclosure.

## Step 3 — Genus-level searching: *Myotis*

Targeting the 20 missing *Myotis* rather than searching species by species worked as predicted — one search surfaced three usable sources.

**Ingested:** *Myotis* cf. *davidii/aurascens* from the Pamir Plateau — 721 free-flight calls, peak 47.41 ± 1.46 kHz, full parameter set. **This independently vindicates an earlier decision.** The Europe batch refused to attach an East Asian *M. davidii* value to the European taxon, flagging it `unknown_no_data` instead. This paper's own Cytb phylogeny shows *M. aurascens* and *M. davidii* sequences forming a single strongly supported clade — the assignment genuinely is unresolved. The caution was correct, and the value stays unattached to Europe.

**Located, not yet fetched — both high priority for the European gaps:**

- **BTO European Bat Sound Identification Guide** (open PDF). Directly attacks the *M. mystacinus* vs *M. brandtii* problem — two of Europe's ten genuine gaps — by compiling calls matched for duration, and reports that *M. brandtii* may produce longer calls (>5.0 ms).
- **Bahnschulte et al., "The soundscape of swarming"** (open, PMC9663320). 564 overlapping call sequences from a major hibernaculum, classified using **linear frequency cepstral coefficients** — call *timbre* — alongside conventional spectral parameters. That's a parameter type entirely absent from this project, and it may separate *Myotis* species that frequency and duration cannot.

## Step 4 — Bibliography mining

Confirmed as the most productive discovery route. Every source above was found through another paper's reference list or citation trail, not through a direct search-engine hit. The Redalyc mirror surfaced only because the Colombian paper cited Orozco-Lugo; the BTO guide surfaced from a *Myotis* identification discussion; the swarming paper from the same thread.

## What's now blocked rather than unfound

Steps 1–4 cleared what was clearable without new access. What remains genuinely needs your machine:

| Blocker | Items |
|---|---|
| GBIF API not in allowlist | 8 ABCD datasets — Indonesia, Cambodia, Yunnan |
| Binary file formats | EuroBaTrait, China S1–S4, Colombia DwC-A, African database |
| Paywalls | Venezuela (30 species), Thailand (19), Obrist, Russo & Jones |
| Bot detection | Trinidad, West Indies, Madagascar, Arava |

## Running totals

Mexico: **0 → 11 species with real values.** Two species corrected from `unknown_no_data` / `value_exists_unretrieved` to measured. Four new sources added to the checklist, two of them open and directly targeting Europe's *Myotis* gaps.

The strategy's core claim held: **the productive unit is the regional library, and the productive route is the bibliography.** One fetched paper delivered 11 species; one genus-level search delivered three sources covering multiple missing species.
