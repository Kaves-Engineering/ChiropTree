# Africa — batch 1: Southern Africa (Swaziland/Eswatini anchor)

First African batch. Africa's bat fauna is large (266 species in sub-Saharan Africa alone, per a modern curated database; 379 continent-wide per the older Africa Chiroptera Report) and, like South America and Asia before it, will need several regional sub-batches. This one covers **24 species** with real primary data, anchored on a single excellent Swaziland (Eswatini) study explicitly stated by its own authors to apply to South Africa and Mozambique as well.

No full named checklist was obtained this batch — flagged honestly below, same treatment as Colombia and Central America earlier in this project.

Files: `africa_swaziland_call_records.csv` (99 records, 24 taxa), `africa_sources.csv`.

## The anchor source

Monadjem et al. 2017 (Acta Chiropterologica, open access via BioOne, full text and both data tables fetched) is built on 178 calls from 145 hand-released individuals across 2005–2016 in the savannas of north-eastern Swaziland. Four parameters per species — duration, frequency of the knee, minimum frequency, and characteristic frequency — with real means, SDs and ranges for 20 species, plus **detection distances and a derived correction factor** for 11 of them. This is comparable in quality to the Australia NSW guide and the Bornean call library from earlier batches.

## Findings

**A real, numeric detectability-bias correction factor** — the first of its kind in this whole project. Detection distance correlates strongly and negatively with call frequency (r = −0.77, p < 0.01): *Hipposideros caffer* is detectable only within 0.3 m, while *Mops condylurus* can be picked up at 30 m. The paper converts this into a per-species correction factor (essentially the inverse of the detection volume) that a user could actually multiply into an activity index to correct for the bias — not just a qualitative "low-intensity callers are under-recorded" statement, which is as far as every other batch in this project has been able to go.

**A cross-family acoustic overlap, the first documented in this project.** Every other overlap-and-confusion finding across 15 batches has been within a family. Here, the completely overlapping *Chaerephon pumilus*/*Mops condylurus* pair (Molossidae) also overlaps entirely with *Taphozous mauritianus* (Emballonuridae) — different families, indistinguishable calls. Duration doesn't rescue the separation either: *T. mauritianus* calls average shorter, but molossid duration is so variable that the ranges still overlap.

**An automated filter failed completely on a genus that's visually easy to spot.** *Myotis bocagii* and *M. tricolor* calls have a distinctive vertical shape that's trivial to recognise by eye on a spectrogram — but the Analook automated filter identified *zero* calls of either species correctly, because the two parameters it uses (frequency of the knee, characteristic frequency) are individually so variable within each species that no threshold separates them. Manual inspection was required for every single call. A clean, quantified example of the general point (already made in Australia, South Asia, and elsewhere in this project) that automated acoustic identification and human visual identification are not interchangeable, even for a genus that's easy for a person to identify.

**Two genuinely undetectable species, confirmed rather than assumed.** *Nycteris thebaica* — common and abundant in the study area — and *Kerivoula lanosa* both produce calls so quiet that even at 0.1 m from the microphone, the Anabat Express detector recorded only unidentifiable noise. This mirrors the *Furipterus horrens* aliasing problem (South America) and the *Plecotus*/whispering-bat pattern seen throughout this project, but here it's from a controlled hand-release experiment at point-blank range, about as strong a confirmation as this kind of claim can get.

## What's missing, stated plainly

- **No named African checklist was obtained.** The modern, taxonomically-current source that should supply one (the 2024 African bat database) publishes its record-level data only via Figshare and a GitHub mirror; the GitHub API was rate-limited and common file-path guesses all failed. This is very likely a five-minute fix for a human with normal browser access — flagged as the top acquisition priority for this continent, the same way Colombia's Darwin Core Archive was flagged.
- **The standard 589-page regional reference** (Monadjem, Taylor, Cotterill & Schoeman, *Bats of Southern and Central Africa*, 2020) is cited by every source in this batch as the source of broad call descriptions for most southern African species, but it's a paywalled book, not fetched.
- **A 2025 Zambian call library** (Taylor-Boyd et al., hosted openly at a University of Pretoria repository) was found but not fetched — likely the natural next extension of this batch into south-central Africa.
- **East, West, Central Africa, North Africa, and Madagascar** are entirely untouched. East Africa alone (Kenya, Tanzania, Uganda, Rwanda, Burundi) has 145 known species per a dedicated identification key, none of which are represented here.

## Verification status

Zero verified rows, consistent with every batch in this project.

## Next

Following the pattern from South America and Asia, Africa will need multiple sub-batches. A natural next step is either the Zambian extension (already identified, open, unfetched) to grow Southern Africa's coverage, or a new sub-batch for East Africa, which has the richest documented fauna on the continent (Kenya, Tanzania, Uganda each over 90 species) and at least one dedicated identification key already located.
