# Maritime/Insular Southeast Asia — echolocation call records (batch 3 of 5 for Asia)

Malaysia, Indonesia, Philippines, Brunei, Singapore, Timor-Leste. Like the previous batch, this one is anchored on a single exceptional source — this time for Malaysian Borneo — with the remaining geography represented by named-but-unfetched sources and, in Indonesia's and the Philippines' case, real and substantial gaps.

**Borneo (shared across Malaysia/Indonesia/Brunei): 31 of 99 species, with full real quantitative data — means, SDs, ranges, sex-disaggregated samples, and geographic comparison across three sites.** Indonesia and the Philippines have essentially nothing ingested this pass, despite the Philippines' famous bat endemism and Indonesia's likely status as the single most speciose country in this entire project.

Files: `maritimeSEA_borneo_call_records.csv` (150 records, 31 species — corrected on audit, see below), `maritimeSEA_sources.csv`.

**Corrected on audit (2026-09-08):** the file originally showed 34 distinct `sci_name` values against a stated "31 species," because two non-species annotation rows (a taxonomic discussion note and a genus-level detectability note) used the species-name field, and *Kerivoula papillosa*'s two size-forms were stored under three related-but-different labels. Fixed: the two note rows are now prefixed `[NOTE-ONLY]` / `[GENUS-LEVEL NOTE...]` so they're excluded from any species count, and the *K. papillosa* labels are consistent. Distinct real species/taxa: 31, matching the source paper exactly.

## The anchor source

McArthur & Khan 2021 (*J. Bat Research & Conservation*, open access, full text with complete Table 1 fetched) describes 508 individuals across 31 species and 8 families from Gunung Mulu National Park plus two comparison sites in Sarawak. It is comparable in depth to Peru's Ugarte-Núñez table or Australia's NSW guide — real means and SDs, separated by recording context (stationary/flight-tent vs. release), with sex-disaggregated sample sizes and a direct geographic comparison across three localities.

## Findings

**A named misclassification risk for an actual endangered species, quantified.** *Hipposideros coxi* is IUCN Endangered, the rarest hipposiderid in the study, and calls at 45–52 kHz — the lowest frequency of any Hipposideridae in Borneo, and non-overlapping with any other species at Gunung Mulu specifically. But in southwestern Sarawak, its range shifts down to 44.5–46.4 kHz, which overlaps directly with the unrelated *Emballonura alecto/monticola* pair (45.2–46.5 kHz) at that location. The paper spells out the conservation consequence directly: a false negative here means a threatened species' roosts go unprotected; a false positive inflates its apparent abundance. This is the clearest, most concrete illustration in this entire project of why "diagnostic" is a location-specific claim, not a species-level constant.

**Sexual dimorphism runs in different directions in closely related species, unexplained.** Female *Rhinolophus creaghi* call higher than males (68.6–72.1 vs. 66.0–69.5 kHz) while male *Hipposideros dyacorum* call higher than females (155.5–165.4 vs. 148.1–156.2 kHz) — and the authors state plainly they don't know why some species show stable peak frequency and others don't, ruling out simple sexual-dimorphism-in-body-size as a full explanation.

**Cryptic-species support from call data with a quantified overlap statistic.** *Kerivoula papillosa* splits into a small form (forearm <44mm, the "true" *papillosa*) and a large form (possibly an undescribed Bornean endemic) — the two forms share only 7% overlap in call parameters, positive acoustic evidence for a taxonomic split that morphology alone had left ambiguous.

**The same detectability-and-classification split seen on every continent, replicated here with real numbers.** DFA classified cave-roosting Rhinolophidae and Hipposideridae+Emballonuridae at 96.6% and 95.6%; the forest-interior Vespertilionidae cluster (*Kerivoula*, *Murina*, *Myotis*) managed only 68.0%. *Kerivoula hardwickii* calls start above 250 kHz — likely at or near the physical ceiling of bat echolocation — and attenuate so fast that the group remains fundamentally capture-dependent for species-level identification, exactly the pattern already documented for this same subfamily pairing in Vietnam (previous batch) and repeatedly across Neotropical gleaners.

**Molossid frequency alternation, on a fourth continent now.** *Chaerephon plicatus* alternates between a broadband type-A call (24.2–38.9 kHz) and a narrower type-B call (22.8–27.2 kHz) in open space — the same phenomenon documented for *Nyctalus*/*Barbastella* in Europe, *Eumops*/*Nyctinomops* in North America, and *Cormura*/*Molossus*/*Promops* across the Neotropics.

## What's missing, and it's substantial

- **Indonesia**: no echolocation source identified or fetched. Country species counts range from 175 (2002) to "over 200" in more recent secondary mentions — likely the single largest national bat fauna in this entire project, and it has zero ingested acoustic data.
- **Philippines**: no echolocation source identified or fetched, despite exceptional endemism (79 described species as of a 2025 report, with ongoing description of new *Murina* species noted in an earlier search this project ran).
- **Brunei** and **Singapore**: no country-specific data beyond what's shared with the Bornean fauna (Brunei) via S-MY-BORNEO's discussion section.
- **Timor-Leste**: not addressed at all this pass.
- Two named Peninsular Malaysian sources — Kingston et al. 1999 (Kerivoulinae/Murininae gleaners) and Kingston et al. 2003 (aerial-hawker frequency alternation, 5 species) — were found and cited but only at abstract level; full quantitative tables not fetched.

## Verification status

Zero verified rows, consistent with every batch in this project.

## Asia tranche status

3 of 5 Asia sub-batches done (South Asia, Mainland Southeast Asia, Maritime/Insular Southeast Asia). Remaining: East Asia (China, Taiwan, Japan, Korea, Mongolia), Central Asia & the Middle East.
