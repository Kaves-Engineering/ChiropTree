# South America — batch 6: Guianas & Venezuela (French Guiana anchor)

Final South American batch. **272 records, 85 taxa** — the largest single-source batch in this project, and it closes South America's regional coverage.

Files: `southamerica_guianas_call_records.csv`, `southamerica_guianas_species_list.csv` (all 103 French Guiana species with per-species sample sizes), `southamerica_guianas_sources.csv`.

## The best source in the whole project

Barataud et al. 2013 has been flagged and deferred in three previous batches. It was worth the wait: an **open PDF on the authors' own website**, fetched in full on the first attempt — text, all twelve tables, and a complete dichotomous identification key.

**2,526 signals, 379 sequences, 80 of French Guiana's 103 species, 8 families**, recorded 2001–2011 in ×10 time expansion. The encoded species list reproduces the paper's Table 1 exactly, including the 23 species that occur in French Guiana but have **no acoustic description at all** — a properly sourced gap list rather than an inferred one.

**A methodological point worth carrying forward.** This study deliberately combines *auditory* analysis — structure, sonority, and the presence and position of an audible energy peak — with computer analysis, and several species separate **only** on the auditory criteria. *Micronycteris* cf. *microtis* and *M. schmidtorum* are distinguished from the rest of Phyllostomidae by a whistled (not nasal) sonority and a **final click** instead of the family's explosive onset. A purely automated reanalysis of this dataset would lose those distinctions entirely. Given how much of this project has tracked automated-classifier accuracy, that is a substantive caveat.

## Findings

**Emballonuridae as a textbook case of acoustic niche partitioning.** The paper states it directly: this family is "a perfect example of acoustic niches within a taxonomic group — each species' sonar has certainly undergone character displacement to avoid interspecific overlap." Thirteen taxa lay out in a clean frequency ladder from *Diclidurus ingens* at 19.6 kHz to *Rhynchonycteris naso* at 95.6 kHz, with frequency-alternation status (mono vs. two- or three-band) as the second axis.

**Two cryptic *Pteronotus* species in syntopy, established acoustically.** Automatic recording produced a clearly bimodal frequency distribution at 52.6 and 58.4 kHz (2,226 signals), leading the authors to conclude two acoustic clades occur together in French Guiana. This independently matches the *P. parnellii* sonotype-complex findings recorded in this project's Central America and Brazil batches.

**A structural geographic difference, not just a spectral one.** *Noctilio leporinus* in French Guiana devotes **24.5%** of its broadband call duration to the constant-frequency component; Martinique 42.7%; Guadeloupe 52.9%. The same species allocates a very different share of its call to CF depending on population — a deeper kind of geographic variation than the frequency shifts documented elsewhere in this project.

**Allometry violated, explicitly.** The authors note that "la logique allométrique est ici non vérifiée" — *Molossus barnesi*, the **smaller** of two congeners, emits the **lower** frequencies. A clean counterexample to the body-size/frequency rule, independently matching the *Pipistrellus kuhlii* ecomorphotype negative result from this project's North Africa batch.

**The phyllostomid problem, quantified per harmonic.** Table 6 gives FME on the fundamental and harmonics 1–3 for 43 species. The authors' conclusion is blunt: acoustic identification of Phyllostomidae "se situe quelque part le long d'un gradient entre problématique et impossible," and for this family mist-netting remains the most effective inventory tool. Overlap is near-total on harmonics 1 and 2.

**But three phyllostomids break their own family's rules.** *Lonchorhina inusitata* uses QFC/FMd with narrowband/broadband alternation like a *Noctilio* — nothing like a phyllostomid — and is separated from the emballonurids it otherwise mimics purely by carrying FME on harmonic 2. *Ametrida centurio* uses whistled linear FM on the fundamental with no energy peak. Both are **easily** identified acoustically.

**The extreme high-frequency case.** *Furipterus horrens* reaches an initial frequency of **250 kHz**, with FME averaging above 150 and reaching 220 kHz — the highest in the fauna. The detectability cost is severe: in a roost, individuals were audible on heterodyne only at **under 2 metres**. The authors also observed them producing audible wing-rustling by rubbing the wings together, and suggest it may compensate socially for vocal folds specialised on frequencies too high for long-range communication.

**A morphology–acoustics–genetics test in progress.** *Myotis riparius* is a genetic complex. The authors separated a littoral morphotype from a primary-forest morphotype, found they differ acoustically (FME 55.0 vs 58.1 kHz), and took biopsies for later genetic analysis — a live three-way concordance test.

## Limitations, stated plainly

- **Venezuela contributes nothing.** Ochoa et al. 2000 was identified early in this project and never fetched. Venezuela has roughly 174 species.
- **Guyana and Suriname contribute nothing.** No dedicated acoustic source was located for either. The DNA-barcoding surveys cited within Barataud et al. (Clare et al. 2006 for Guyana, Borisenko et al. 2008 for Suriname) are genetic, not acoustic. Genuine gap.
- **23 French Guiana species have no acoustic description**, including *Chrotopterus auritus*, *Vampyrum spectrum*, *Macrophyllum macrophyllum*, five molossids and three *Lasiurus*. All are listed by name in the species-list file.
- **The source is in French**, which is why it sat unfetched through three earlier batches.

## South America: complete

Brazil/Amazon, Ecuador, Colombia, Peru, Southern Cone, Guianas+Venezuela. All six regional sub-batches done.

## Verification status

Zero verified rows, consistent with every batch in this project.
