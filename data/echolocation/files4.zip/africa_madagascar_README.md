# Africa — batch 6: Madagascar & Indian Ocean islands

Sixth and final African batch. Madagascar is deliberately excluded from the sub-Saharan African bat database used elsewhere in this project, and has a heavily endemic fauna.

**10 named taxa, 21 records** — but this batch is unusual in that its *qualitative* findings are high-confidence while its *numeric* values are mostly not retrieved. That split is flagged per-record via a new `extraction_confidence` column (16 high, 4 medium, 1 low).

Files: `africa_madagascar_call_records.csv`, `africa_madagascar_sources.csv`.

## The anchor source was not retrieved, and it matters

Kofoky et al. 2009 is exactly the right paper: 153 bats, 15 species, three families, five measured variables, with six species described acoustically for the first time. **I could not fetch it.** BioOne returned a bot-detection block — the same obstacle hit in the Zambia batch, where a University of Pretoria mirror rescued it; no equivalent mirror exists here — and ResearchGate returned HTTP 429 rate-limiting.

What that leaves: abstract-level findings that are unambiguous and directly quoted (encoded as **high** confidence), plus two fragmentary numeric rows from a partial table extract where **column assignment could not be verified** (encoded **medium** and **low**). The *Triaenops* row in particular is truncated mid-table and should not be used without the original.

This is the single highest-priority target for Madagascar: one successful fetch supplies full parameters for all 15 species.

## Findings that are solid

**An entire island fauna reduces to three acoustic groups.** Kofoky et al. classify all 15 species into exactly three: **Constant Frequency** (hipposiderids *plus* Emballonura), **FM/QCF** (dominated by vespertilionids), and **FM** (containing exactly one species, *Myotis goudoti*). That is a strikingly simple acoustic structure for a whole fauna.

**Malagasy *Emballonura* group with CF hipposiderids — which is anomalous.** In every other region of this project, emballonurids are narrowband QCF or multiharmonic FM: *Saccopteryx* and *Cormura* in the Neotropics, *Taphozous* in Africa and South Asia, *Emballonura* in Borneo. Malagasy *Emballonura* being placed in a Constant Frequency group alongside hipposiderids is a genuine outlier worth flagging for the tree page.

**Island fauna, higher classification accuracy.** Overall DFA accuracy was **82.2%** across 15 species — well above continental assemblages measured the same way in this project: Zambia 52.5–55.9%, Cameroon 69.7%, Borneo 68% for forest vespertilionids. Consistent with an impoverished island fauna simply having fewer confusable species.

**Six first-ever call descriptions**, all endemics or near-endemics: *Scotophilus tandrefana*, *S. marovaza*, *Emballonura tiavato*, *Neoromicia* spp., *N. malagasyensis*, *Triaenops auritus*.

**A sexual-dimorphism result that inverts the Kenya finding.** *Hipposideros commersoni* is confirmed to differ in echolocation calls between males and females. Contrast the Kenya batch, where *Macronycteris gigas* and *M. vittata* were strongly size-dimorphic yet the sexes called at *identical* frequencies. Same family, opposite outcomes.

**A taxonomic note that closes a loop from batch 2.** *Hipposideros commersoni* is now restricted to Madagascar; mainland African populations formerly carrying that name are *Macronycteris vittata*. The Kenya batch recorded the mainland side of exactly this split.

## Limitations

- **No named Malagasy species checklist was obtained.** Goodman (2011), *Les chauves-souris de Madagascar*, is the standard reference and was not fetched. The commonly cited ~46–50 species figure is not independently verified here, so no coverage percentage is claimed.
- **A dedicated Malagasy field guide with call descriptions exists and was not fetched.** Russ & Bennett (2001) contains numbered sonograms per species and recordings for at least 14 named taxa — the island equivalent of the NSW and Southern Africa guides that anchored earlier batches. It is a book, not a journal article.
- **Ramasindrazana et al. 2013** covers *Triaenops* and *Paratriaenops* call variation in detail and was not fetched. This matters because morphology is reported to be highly similar among Malagasy rhinonycterids, making acoustics the practical identification route for that group.
- **The Comoros, Seychelles, Mascarenes and other Indian Ocean islands are untouched.**

## Africa: complete

| Batch | Region | Species |
|---|---|---|
| 1 | Southern Africa | 24 |
| 2 | East Africa (Kenya) | 10 |
| 3 | Zambia | 22 (14 new) |
| 4 | West & Central Africa | 9 (7 new) |
| 5 | North Africa | 7 (7 new) |
| 6 | Madagascar | 10 (10 new) |
| | **Unique African + Malagasy species** | **70** |
| | Continental total (mainland) | 379 |

## Verification status

Zero verified rows, consistent with every batch in this project.
