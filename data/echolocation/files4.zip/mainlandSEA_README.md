# Mainland Southeast Asia — echolocation call records (batch 2 of 5 for Asia)

Myanmar, Thailand, Laos, Cambodia, Vietnam. This batch is anchored entirely on one exceptional Vietnamese source; the other four countries are represented only by species counts and, in most cases, a named-but-unfetched dedicated acoustic paper.

**Vietnam: 87–88 species, 74% of the country's 118 echolocating species (129 total), with full species list and call-type classification for every one.** The other four countries have no ingested acoustic data this pass — a real and stated gap, not a silent one.

Files: `mainlandSEA_vietnam_species.csv` (88 species, family, genus, call-type), `mainlandSEA_vietnam_newspecies_quant.csv` (5 species with full real numeric values), `mainlandSEA_sources.csv`.

**Corrected on audit (2026-09-08):** the `genus` column originally held a subfamily or tribe name (e.g. "Pipistrellini", "Murininae") instead of the true genus for 35 of 88 rows (40%) — a leftover from how the source's own subsection headings were transcribed. Fixed by deriving genus directly from each binomial. The corrected file now yields exactly 28 unique genera, matching the paper's own stated count for the first time. Separately, *Hipposideros grandis* and *H. poutensis* were originally listed as two independently-confirmed species; the source paper actually groups them as one of only two uncertain-identification pairs in the whole study (the other being *Kerivoula* cf. *hardwickii*, already marked as uncertain here). Both rows are retained but now carry an explicit uncertainty flag matching that treatment.

## Why this batch is Vietnam-only in practice

Győrössy et al. 2024 (*Scientific Reports*, open access, full text fetched) is described by its own authors as covering ground "a comprehensive call library covering such a large number of distinct species...did not exist for any single country in mainland Asia" before this paper. It's a genuinely exceptional source: 3,438 pulses from 1,042 recordings across 30 provinces and 3 municipalities, 2006–2023, with species identity confirmed by DNA barcoding where morphology was ambiguous, and every recording deposited in ChiroVox for reanalysis.

**The one real limitation:** the paper's actual per-species numeric tables (Tables 1–8, mean ± SD, min–max, n) are rendered as image/table objects that a text-only fetch cannot extract — the same situation as South Asia's Supplementary Material 3 in the previous batch. What's captured here is the complete species list, genus, family, and call-type classification (FM / FM-QCF / cDFM / CF-FM / QCF) for all 87–88 taxa, plus full numeric values for the five species given first-ever prose descriptions (see below). The paper links a directly downloadable Table S1 spreadsheet — the clear top acquisition target for this batch.

## Findings

**A newly-named call shape for an Asian-specific subfamily.** *Murininae* (*Murina*, *Harpiocephalus*) calls are classified here as "cDFM" — checked downward FM, an upward-modulated onset followed by a downward phase — a structure distinct enough from ordinary FM that the authors gave it its own category, one of only three major signal types identified across the entire 87-species dataset (FM, FM-QCF, cDFM).

**Five first-ever call descriptions, with real numbers:**
- *Glischropus bucephalus*: FMAXE 56.7 ± 1.8 kHz, duration 2.6 ± 0.5 ms, from 3 flight-tent males.
- *Kerivoula depressa* and *K. dongduongana*: both broadband, extremely high-starting FM (215–238 kHz down to 72–77 kHz), FMAXE ~128–129 kHz — among the highest-frequency calls in this entire project.
- *Myotis laniger*: FMAXE 54.7 ± 2.6 kHz, from a single flight-tent female.
- *Myotis sicarius*: the first record of this species anywhere in Southeast Asia (previously known only from Nepal), FMAXE 36.6 ± 0.6 kHz — a species range extension made *through* the acoustic/capture work itself, not independently confirmed by it.

**The paper explicitly flags its own weak spots**, a rare level of candor: *Hipposideros pratti*, *Miniopterus magnater*, *M. pusillus*, and *Myotis altarium* all had genuinely limited sample sizes, and the authors state directly that "the variation in calls recorded for these species may not be sufficiently representative and should be interpreted with caution." Flagged per-species in the records.

**Old World lingual echolocation, now on a third continent (after Africa's *Rousettus aegyptiacus* and no equivalent in the Americas).** *Rousettus leschenaultii* is the only Pteropodidae species studied — tongue-click echolocation, atonal, single dominant low-frequency FM structure — structurally the same non-laryngeal system documented for its African congener in the Europe batch, now confirmed present and studied in mainland Asia.

## The other four countries: named sources, not yet fetched

- **Cambodia**: Phauk, Sarith & Furey 2013, "Cambodian bat echolocation: a first description of assemblage call parameters" — a dedicated national source, cited in Győrössy et al.'s own bibliography, not independently retrieved this pass.
- **Thailand**: Hughes et al. 2011 covers Vespertilionidae, Emballonuridae, Nycteridae and Megadermatidae specifically — also cited within S-VN24, not fetched.
- **Laos**: no dedicated acoustic source identified in this pass.
- **Myanmar**: no dedicated acoustic source identified at all. The country's species count itself (95, per a 2005 review) is two decades stale — subsequent splits in *Murina*, *Myotis*, *Kerivoula* and *Hypsugo* almost certainly mean the true total is higher, and no updated figure was located.

Country species counts (approximate, uneven vintage, not summable due to range overlap): Myanmar ~95 (2005), Thailand ~119–146 (2006–recent), Laos ~92–100 (2011–2014), Cambodia ~66–80 (2011–2020s), Vietnam 129 (2024, the most current and reliable figure in this batch by a wide margin).

## Verification status

Zero verified rows, consistent with every batch in this project.

## Asia tranche status

2 of 5 Asia sub-batches done (South Asia, Mainland Southeast Asia). Remaining: Maritime/Insular Southeast Asia (Malaysia, Indonesia, Philippines, Brunei, Singapore, Timor-Leste), East Asia (China, Taiwan, Japan, Korea, Mongolia), Central Asia & the Middle East.
