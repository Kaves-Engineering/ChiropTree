# Africa — batch 3: Zambia (south-central Africa)

Third African batch, and the one that clears the most-deferred source in this project. The Zambian call library was identified and postponed in *both* previous African batches; it is now fetched in full.

**22 species, 118 records, 238 individuals across 16 Zambian sites.** Fourteen of the 22 species are new to this project's African coverage, bringing the African total from 34 to **48 species**.

Files: `africa_zambia_call_records.csv`, `africa_zambia_sources.csv`.

## A method note worth recording

The publisher copy (BioOne) returned a bot-detection block. The University of Pretoria institutional repository hosted the identical paper as an open PDF, which fetched on the first attempt. This is the exact technique logged in this project's paywall registry as "try the institutional mirror" — it worked cleanly here, and is worth trying first on any Acta Chiropterologica or similar society-journal paper.

## What makes this source unusually good

238 individuals, 22 species, 16 sites, 2015–2023. Species identifications confirmed genetically (COI and cytochrome b barcoding) for a substantial subset — 35 of 46 *Laephotis capensis*, all 16 *Neoromicia anchietae*, 11 of 12 *N. zuluensis*. Recordings deliberately standardised as release calls with quality filtering (SonoBat quality rating > 0.8, sequences of 10+ pulses only).

The authors also did something rare: they **tested whether different detector models produce different parameter values**. Across six detector models and 18 species, only End Slope differed significantly — and that parameter was not one of the two that mattered for classification. This is direct evidence that multi-source community-science acoustic data can be pooled, with caveats, which very few sources in this project have actually tested.

## Findings

**The clearest quantification yet of the "functional group yes, species no" pattern.** Discriminant analysis assigned calls to *functional group* (open aerial, edge aerial, edge trawl, narrow flutter) with **97–98.5% accuracy**, but to *species* with only **52.5–55.9%**. Of 17 species evaluated, nine scored 50% or lower; only four exceeded 98% (*Macronycteris vittatus* and *Rhinolophus simulator* at 100%, *Mops nigeriae* 99.1%, *Afronycteris nana* 98.2%). This project has repeatedly encountered species-level acoustic ambiguity; this is the first source to put a single clean number on both halves of it from one dataset.

**A 10 kHz single-species discrepancy with no distribution overlap at all.** *Vansonia rueppellii*'s Frequency of Maximum Power here is more than 10 kHz higher than the standard regional reference (Monadjem et al. 2020) — and higher than an earlier manual measurement from Kafue National Park *in Zambia itself*. Its preceding interval is also much lower (80.8 vs 131.7 ms). The authors flag it as possibly real regional variation or a taxonomic problem needing resolution.

**A systematic, method-driven offset affecting every species.** The study's Frequency of Maximum Power values are consistently higher than the equivalent Frequency of Maximum Energy in the standard reference — across *all* species, not just high-duty-cycle ones, so Doppler shift can't explain it. The authors attribute it to measurement method: SonoBat computes per-pulse automatically, while BatSound (used in the reference) requires a manual approach. **This is a direct, documented example of two credible sources disagreeing on the same species purely because of software.** Anyone merging African call data across sources needs to know this.

**Three live taxonomic problems, flagged rather than smoothed over.** *Miniopterus* is left at genus level because the southern African complex is unresolved (its frequency sits closer to *M. mossambicus* than *M. natalensis*, but both occur in Zambia). *Nycteris* likewise, after inconclusive genetics. And *Laephotis botswanae* has been synonymised into *L. angolensis* — meaning older African records under the former name need remapping, which matters directly for merging this batch with older sources.

## Limitations, stated plainly

- **22 species is about a quarter of Zambia's fauna**, which the authors state directly. Zambia holds roughly two-thirds of the 125+ species known from the southern African region.
- **Some functional groups are barely or not represented** — narrow passive bats have a single individual; open aerial has only two species.
- **Only 5 of 20 available parameters were ingested.** The supplementary PDF (Tables S1–S4) holds the full 20-parameter dataset for all 22 species and was not fetched. That single file would roughly quadruple this batch's parameter depth.
- **These are release calls**, which the authors note are generally higher-frequency and shorter than free-flying calls — not directly comparable to passive monitoring recordings.

## Africa running total

| Batch | Region | Species |
|---|---|---|
| 1 | Southern Africa (Eswatini/South Africa) | 24 |
| 2 | East Africa (Kenya) | 10 |
| 3 | Zambia (south-central) | 22 (14 new) |
| | **Unique African species covered** | **48** |
| | Continental total (Africa Chiroptera Report) | 379 |

Remaining African regions: West Africa, Central Africa, North Africa, and Madagascar + Indian Ocean islands. *Bats of Southern and Central Africa* (2020) is now the most-cited inaccessible source across all three African batches.

## Verification status

Zero verified rows, consistent with every batch in this project.
