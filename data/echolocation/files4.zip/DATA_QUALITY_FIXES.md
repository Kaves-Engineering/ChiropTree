# Data quality: four structural problems diagnosed and fixed

These were uncovered while assessing the dataset, but they are **not analysis-specific**. Every one of them would put a wrong number on a ChiropTree species page. All four are now fixed in `MASTER_call_records.csv`; nothing was deleted, everything is additive and reversible.

## Problem 1 — Harmonic conventions were mutually incompatible

**The diagnosis.** Three sources numbered harmonics three different ways, and the labels were stored verbatim:

- **Barataud (French Guiana)** calls the fundamental `FOND` and numbers harmonics *above* it: `H1` = **second** harmonic.
- **Yoh et al. (Amazon)** numbers from the fundamental: `1` = fundamental, `2` = second harmonic.
- **Pennay & Lavery (Solomon Is.)** state explicitly in their own guide that `H1` = the fundamental — a third convention.

So a record labelled `H1` meant the second harmonic in one file and the fundamental in another. This is exactly how *Carollia perspicillata* ended up with both "31 kHz" and "69 kHz" as its peak frequency: same animal, same call, different harmonic.

**The evidence it's a convention clash and not an error:** across 36 species with both values stored, the ratio H1/FOND has a median of **2.05** and H2/FOND a median of **2.74**. H1 sits at twice the fundamental — it *is* the second harmonic.

**Important negative finding.** I tested whether an integer-ratio check could be used as an error detector. **It can't.** In a broadband FM sweep, the frequency of maximum energy of each harmonic occurs at a *different point in the sweep*, so the values are not required to be exact integer multiples. Ratios of 2.1 and 2.7 are physically normal, not corrupt. Anyone building a validator should not flag these.

**The fix.** New columns `harmonic_n` (canonical: fundamental = 1) and `harmonic_convention_source` (records the original convention and whether the conversion is verified or assumed). 168 trait names that baked a harmonic into the name (`fmaxE_H2_kHz`) were rewritten to `trait + harmonic_n`; 482 existing labels were converted. Original trait names are preserved in `notes`.

## Problem 2 — 88 trait names, no way to tell which were comparable

**The diagnosis.** `peak_frequency_kHz`, `fmaxE_kHz`, `characteristic_frequency_kHz`, `frequency_of_max_power_kHz`, `resting_CF_frequency_kHz`, `frequency_of_knee_kHz` — these look interchangeable and are not. Characteristic frequency is the *flattest part* of an Anabat call; peak energy is the *loudest* point; resting frequency is measured on a stationary Doppler-compensating bat and is systematically **higher** than what the same bat emits in flight.

**The fix.** Three new columns: `trait_concept` (what is physically measured), `trait_measure_type` (point / bound / range / derived / categorical), and `comparable_group` — a hard flag for what may legitimately be pooled. 88 raw names collapse to 70 concepts and **17 comparable groups**. `PEAK_ENERGY` (663 records) is the largest and is the one safe to compare across sources. `CHARACTERISTIC` (119), `CF_COMPONENT` (46) and `RESTING_CF` (9) are deliberately kept separate. `FIELD_KEY_ONLY` isolates heterodyne tuning bands, which are not measurements at all.

## Problem 3 — Recording context was 41 free-text strings

**The diagnosis.** `"search | free_flying"`, `"release call"`, `"hand-released"`, `"Flying in tent"`, `"Flight-Cluttered"` — all describing a confound this project repeatedly documented as worth **20–50 kHz**. Unusable as free text.

**The fix.** `context_class` (7 values: hand_release 1002, free_flying 997, hand_held 89, enclosure 61, heterodyne_field_key 19, roost_or_cave 7, other_or_unclear 73) and `clutter_class` (cluttered / semi_cluttered / open). Hand-release and free-flying are now separable in one filter.

## Problem 4 — Taxonomy could not be joined to anything

**The diagnosis.** Of 499 name strings: 430 clean binomials, but also 17 subspecies trinomials, 19 two-species composites (`Cynomops abrasus/greenhalli`), 14 population qualifiers (`Hipposideros cervinus (Guadalcanal)`), 10 `cf.`/`aff.` uncertain IDs, 6 genus-only, 17 meta-rows, 3 malformed, and 2 orthographic duplicate pairs (*Diaemus youngi*/*youngii*, *Macronycteris vittata*/*vittatus*).

**The fix — and the design choice.** I did **not** silently rewrite names. Three new columns: `name_status` (what kind of name it is), `binomial_for_join` (parent binomial where one can be safely derived), and `join_confidence` (high / low / genus_only / exclude). Subspecies and population qualifiers collapse onto their parent binomial; composites, meta-rows and malformed strings are marked **exclude** rather than guessed. Result: **439 distinct binomials safe to join** to MDD or a phylogeny, with 77 records honestly excluded.

## The result

Re-running the conflict test that started this:

| | Species/strata with >20 kHz internal disagreement |
|---|---|
| Pooling blindly (previous behaviour) | **50** |
| After stratifying by comparable_group + harmonic_n + context_class | **6** |

**44 of the 50 conflicts were bookkeeping, not biology.**

## The 6 survivors — `CONFLICT_REGISTER.csv`

These are real and each has a diagnosed likely cause:

- ***Furipterus horrens*** (152 vs 191 kHz) — known **aliasing** artifact; early recordings used sampling rates below twice the call frequency (Falcão et al. 2015). The low values are underestimates, not a second population.
- ***Thyroptera tricolor*** (51 vs 123 kHz) and ***T. discifera*** (53 vs 112.5) — both near a 1:2 ratio. Almost certainly a fundamental-vs-second-harmonic mismatch that survived normalisation because one source left the harmonic **unlabelled**. Highest-priority check.
- ***Myotis albescens*** (64 vs 125.9 kHz) — already flagged as suspect at ingest; likely a misidentification or different call phase.
- ***Noctilio leporinus*** (34.6 vs 65 kHz) — **genuine** geographic variation, documented across French Guiana/Martinique/Guadeloupe in both frequency and CF-duration ratio. Not an error.
- ***Harpiocephalus harpia*** (57 vs 88.1 kHz) — two South Asian studies disagree, both free-flying. Unresolved; needs the primary papers.

## What this means for the ChiropTree page

Render a species value only where `comparable_group = PEAK_ENERGY`, `join_confidence = high`, and `harmonic_n` is known — and show `context_class` alongside it. For the six species in the conflict register, show the range and the disagreement rather than a single number. That's more honest and, for *Noctilio leporinus* at least, more interesting.
